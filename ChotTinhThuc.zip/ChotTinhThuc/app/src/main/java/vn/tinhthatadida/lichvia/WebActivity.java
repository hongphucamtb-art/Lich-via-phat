package vn.tinhthatadida.lichvia;

import android.app.Activity;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/** Xem trang kinh sach, phap am, video, hinh anh ngay trong app (can co internet). */
public class WebActivity extends Activity {

    private WebView web;
    private Object backCallback;

    private static final String AN_DAU_TRANG =
            "(function(){var s=document.createElement('style');"
            + "s.innerHTML='header,footer,.navbar,.site-header,.site-footer,#header,#footer{display:none!important}';"
            + "document.head.appendChild(s);})()";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String url = getIntent().getStringExtra("url");
        String ten = getIntent().getStringExtra("ten");

        final LinearLayout goc = new LinearLayout(this);
        goc.setOrientation(LinearLayout.VERTICAL);
        goc.setBackgroundColor(0xFF5A1616);

        LinearLayout thanh = new LinearLayout(this);
        thanh.setOrientation(LinearLayout.HORIZONTAL);
        thanh.setGravity(Gravity.CENTER_VERTICAL);
        thanh.setBackgroundColor(0xFF7B1E1E);
        int p8 = dp(8);
        thanh.setPadding(p8, p8, p8, p8);

        TextView ve = new TextView(this);
        ve.setText("‹");
        ve.setTextColor(0xFFF3E3B8);
        ve.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        ve.setPadding(dp(10), 0, dp(14), 0);
        ve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView td = new TextView(this);
        td.setText(ten == null ? "" : ten);
        td.setTextColor(0xFFF3E3B8);
        td.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        td.setTypeface(Typeface.DEFAULT_BOLD);
        thanh.addView(ve);
        thanh.addView(td, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final ProgressBar tai = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        tai.setMax(100);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String u) {
                v.evaluateJavascript(AN_DAU_TRANG, null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int n) {
                tai.setProgress(n);
                tai.setVisibility(n >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        goc.addView(thanh, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        goc.addView(tai, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)));
        goc.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(goc);

        if (Build.VERSION.SDK_INT >= 21) {
            goc.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    int t, bt;
                    if (Build.VERSION.SDK_INT >= 30) {
                        Insets i = insets.getInsets(WindowInsets.Type.systemBars()
                                | WindowInsets.Type.displayCutout());
                        t = i.top;
                        bt = i.bottom;
                    } else {
                        t = insets.getSystemWindowInsetTop();
                        bt = insets.getSystemWindowInsetBottom();
                    }
                    goc.setPadding(0, t, 0, bt);
                    return insets;
                }
            });
            goc.requestApplyInsets();
        }

        if (url != null) web.loadUrl(url);

        if (Build.VERSION.SDK_INT >= 33) {
            android.window.OnBackInvokedCallback cb = new android.window.OnBackInvokedCallback() {
                @Override
                public void onBackInvoked() {
                    quayLai();
                }
            };
            backCallback = cb;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb);
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void quayLai() {
        if (web != null && web.canGoBack()) web.goBack();
        else finish();
    }

    @Override
    public void onBackPressed() {
        quayLai();
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(
                    (android.window.OnBackInvokedCallback) backCallback);
        }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
