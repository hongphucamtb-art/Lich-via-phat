package vn.tinhthatadida.lichvia;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

/** Thong bao Kinh Phap Cu moi ngay mot cau. */
public class PhapCuReceiver extends BroadcastReceiver {

    private static final String FILE = "phap_cu";
    private static final String ACTION = "vn.tinhthatadida.lichvia.PHAPCU";
    private static final int MA = 200001;

    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            String[] c = cauHomNay(ctx);
            if (c != null) {
                NhacNho.taoKenh(ctx);
                NhacNho.banTin(ctx, MA, "Lời Phật dạy hôm nay", c[0] + "\n— " + c[1], new Prefs(ctx).chuong());
            }
        } catch (Exception ignored) {
        }
        datLai(ctx);
    }

    private static SharedPreferences sp(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static void luu(Context ctx, boolean bat, int gio, int phut) {
        sp(ctx).edit().putBoolean("bat", bat).putInt("gio", gio).putInt("phut", phut).commit();
        datLai(ctx);
    }

    /** So ngay tinh tu 1/1/1970 (theo ngay dia phuong), giong cach tinh trong giao dien. */
    public static long soNgay() {
        Calendar h = Calendar.getInstance();
        GregorianCalendar u = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        u.clear();
        u.set(h.get(Calendar.YEAR), h.get(Calendar.MONTH), h.get(Calendar.DAY_OF_MONTH));
        return u.getTimeInMillis() / 86400000L;
    }

    /** Xen ke moi ngay: ngay chan Kinh Phap Cu, ngay le loi Phat va chu To. [noi dung, nguon] */
    public static String[] cauHomNay(Context ctx) throws Exception {
        InputStream in = ctx.getAssets().open("loiday.json");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int r;
        while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
        in.close();
        org.json.JSONObject o = new org.json.JSONObject(bo.toString("UTF-8"));
        long n = soNgay();
        JSONArray ds = o.getJSONArray(n % 2 == 0 ? "pc" : "ld");
        long h = n / 2;
        int i = (int) (((h % ds.length()) + ds.length()) % ds.length());
        JSONArray c = ds.getJSONArray(i);
        return new String[]{c.getString(0), c.getString(1)};
    }

    public static void datLai(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, PhapCuReceiver.class);
        i.setAction(ACTION);
        int co = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) co |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getBroadcast(ctx, MA, i, co);
        am.cancel(pi);
        SharedPreferences s = sp(ctx);
        if (!s.getBoolean("bat", true)) return;
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, s.getInt("gio", 6));
        c.set(Calendar.MINUTE, s.getInt("phut", 0));
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis() + 1000) c.add(Calendar.DAY_OF_MONTH, 1);
        long khi = c.getTimeInMillis();
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, khi, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, khi, pi);
        }
    }
}
