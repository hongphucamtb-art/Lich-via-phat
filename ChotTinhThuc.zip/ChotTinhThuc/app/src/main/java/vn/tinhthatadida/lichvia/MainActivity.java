package vn.tinhthatadida.lichvia;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.List;

/**
 * Man hinh chinh: toan bo giao dien Chot Tinh Thuc chay trong WebView
 * (tai tu assets/www/index.html). Phan nhac nho, bao thuc, luu cai dat
 * van do ma Java cu dam nhan, noi voi giao dien qua cau noi "App".
 */
public class MainActivity extends Activity {

    private WebView web;
    private Prefs p;
    private View tren, duoi;
    private Object backCallback;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = new Prefs(this);

        LinearLayout goc = new LinearLayout(this);
        goc.setOrientation(LinearLayout.VERTICAL);
        goc.setBackgroundColor(0xFFFBF3E4);
        tren = new View(this);
        tren.setBackgroundColor(0xFF5A1616);
        duoi = new View(this);
        duoi.setBackgroundColor(0xFFFFFDF7);
        web = new WebView(this);
        goc.addView(tren, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0));
        goc.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        goc.addView(duoi, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0));
        setContentView(goc);
        apVien(goc);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.setBackgroundColor(0xFFFBF3E4);
        web.addJavascriptInterface(new CauNoi(), "App");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    moNgoai(url);
                    return true;
                }
                return false;
            }
        });
        web.loadUrl("file:///android_asset/www/index.html");

        NhacNho.taoKenh(this);
        NhacNho.datLichNhac(this);
        ViecReceiver.datLai(this);

        if (!p.daChao()) {
            startActivity(new Intent(this, ChaoMungActivity.class));
        }
        xinQuyenThongBao();

        if (Build.VERSION.SDK_INT >= 33) {
            android.window.OnBackInvokedCallback cb = new android.window.OnBackInvokedCallback() {
                @Override
                public void onBackInvoked() {
                    quayLai();
                }
            };
            backCallback = cb;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb);
        }
    }

    private void apVien(final View goc) {
        if (Build.VERSION.SDK_INT < 21) return;
        goc.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int t, bt, l, r;
                if (Build.VERSION.SDK_INT >= 30) {
                    Insets i = insets.getInsets(WindowInsets.Type.systemBars()
                            | WindowInsets.Type.displayCutout());
                    Insets k = insets.getInsets(WindowInsets.Type.ime());
                    t = i.top;
                    bt = Math.max(i.bottom, k.bottom);
                    l = i.left;
                    r = i.right;
                } else {
                    t = insets.getSystemWindowInsetTop();
                    bt = insets.getSystemWindowInsetBottom();
                    l = insets.getSystemWindowInsetLeft();
                    r = insets.getSystemWindowInsetRight();
                }
                LinearLayout.LayoutParams a = (LinearLayout.LayoutParams) tren.getLayoutParams();
                a.height = t;
                tren.setLayoutParams(a);
                LinearLayout.LayoutParams c = (LinearLayout.LayoutParams) duoi.getLayoutParams();
                c.height = bt;
                duoi.setLayoutParams(c);
                goc.setPadding(l, 0, r, 0);
                return insets;
            }
        });
        goc.requestApplyInsets();
    }

    private void xinQuyenThongBao() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 77);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.evaluateJavascript("window.napCaiDat&&napCaiDat()", null);
        }
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(
                    (android.window.OnBackInvokedCallback) backCallback);
        }
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        quayLai();
    }

    private void quayLai() {
        if (web == null) {
            finish();
            return;
        }
        web.evaluateJavascript("window.nutQuayLai?nutQuayLai():false", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"true".equals(v)) {
                    finish();
                }
            }
        });
    }

    private void moNgoai(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Không mở được liên kết", Toast.LENGTH_SHORT).show();
        }
    }

    private static String ymd(Calendar c) {
        return c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.DAY_OF_MONTH);
    }

    /** Cau noi giua giao dien (JavaScript) va phan Java. */
    public class CauNoi {

        @JavascriptInterface
        public String layCaiDat() {
            try {
                JSONObject o = new JSONObject();
                o.put("ten", p.ten());
                o.put("pd", p.phapDanh());
                o.put("cheDo", p.cheDoChay());
                o.put("truoc", p.nhacTruoc());
                o.put("gio", p.gioNhac());
                o.put("phut", p.phutNhac());
                o.put("trai", p.nhacNgayTrai());
                o.put("via", p.nhacNgayVia());
                o.put("chuong", p.chuong());
                JSONArray nk = new JSONArray();
                List<Calendar> ds = p.dsNgayChay();
                for (Calendar c : ds) nk.put(ymd(c));
                o.put("nhatKy", nk);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void luuCaiDat(String json) {
            try {
                JSONObject o = new JSONObject(json);
                p.setTen(o.optString("ten", ""));
                p.setPhapDanh(o.optString("pd", ""));
                p.setCheDoChay(o.optInt("cheDo", NgayLe.CHAY_THAP_TRAI));
                p.setNhacTruoc(o.optInt("truoc", 1));
                p.setGioNhac(o.optInt("gio", 19), o.optInt("phut", 0));
                p.setNhacNgayTrai(o.optBoolean("trai", true));
                p.setNhacNgayVia(o.optBoolean("via", true));
                p.setChuong(o.optBoolean("chuong", true));
                NhacNho.datLichNhac(MainActivity.this);
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void danhDauChay(String khoa, String co) {
            try {
                String[] a = khoa.split("-");
                Calendar c = Calendar.getInstance();
                c.set(Integer.parseInt(a[0]), Integer.parseInt(a[1]) - 1, Integer.parseInt(a[2]));
                p.danhDauAnChay(c, "true".equals(co));
            } catch (Exception ignored) {
            }
        }

        /** Rung may: mau = "ms" hoac "cho,rung,cho,rung,..." (ms); cuong = 1..255. */
        @JavascriptInterface
        public void rung(String mau, int cuong) {
            try {
                android.os.Vibrator v;
                if (Build.VERSION.SDK_INT >= 31) {
                    android.os.VibratorManager vm = (android.os.VibratorManager)
                            getSystemService(android.content.Context.VIBRATOR_MANAGER_SERVICE);
                    v = vm == null ? null : vm.getDefaultVibrator();
                } else {
                    v = (android.os.Vibrator) getSystemService(android.content.Context.VIBRATOR_SERVICE);
                }
                if (v == null || !v.hasVibrator()) return;
                String[] a = mau.split(",");
                int amp = Math.max(1, Math.min(255, cuong));
                if (a.length == 1) {
                    long ms = Long.parseLong(a[0].trim());
                    if (Build.VERSION.SDK_INT >= 26) {
                        v.vibrate(android.os.VibrationEffect.createOneShot(ms, amp));
                    } else {
                        v.vibrate(ms);
                    }
                } else {
                    long[] t = new long[a.length];
                    int[] am = new int[a.length];
                    for (int i = 0; i < a.length; i++) {
                        t[i] = Long.parseLong(a[i].trim());
                        am[i] = (i % 2 == 0) ? 0 : amp;
                    }
                    if (Build.VERSION.SDK_INT >= 26) {
                        v.vibrate(android.os.VibrationEffect.createWaveform(t, am, -1));
                    } else {
                        v.vibrate(t, -1);
                    }
                }
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void datNiemPhat(String json) {
            try {
                NiemPhatReceiver.datTatCa(MainActivity.this, json);
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void luuDuLieu(String khoa, String giaTri) {
            try {
                MainActivity.this.getSharedPreferences("du_lieu", android.content.Context.MODE_PRIVATE).edit().putString(khoa, giaTri).commit();
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public String layDuLieu(String khoa) {
            try {
                return MainActivity.this.getSharedPreferences("du_lieu", android.content.Context.MODE_PRIVATE).getString(khoa, "");
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void datViec(String json) {
            ViecReceiver.datTatCa(MainActivity.this, json);
        }

        @JavascriptInterface
        public void thuThongBao() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    xinQuyenThongBao();
                    NhacNho.taoKenh(MainActivity.this);
                    NhacNho.banTin(MainActivity.this, 1999, "Thử thông báo — Chợt Tỉnh Thức",
                            "Thông báo hoạt động tốt. Nam mô A Di Đà Phật.", p.chuong());
                }
            });
        }

        @JavascriptInterface
        public void chaoLai() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(MainActivity.this, ChaoMungActivity.class));
                }
            });
        }

        @JavascriptInterface
        public void moCaiDatApp() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        i.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void moNgoai(final String url) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    MainActivity.this.moNgoai(url);
                }
            });
        }

        @JavascriptInterface
        public void moWeb(final String url, final String ten) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(MainActivity.this, WebActivity.class);
                    i.putExtra("url", url);
                    i.putExtra("ten", ten);
                    startActivity(i);
                }
            });
        }
    }
}
