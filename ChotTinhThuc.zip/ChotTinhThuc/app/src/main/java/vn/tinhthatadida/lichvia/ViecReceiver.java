package vn.tinhthatadida.lichvia;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/** Bao thuc cho "Viec can lam" dat trong muc Lich. */
public class ViecReceiver extends BroadcastReceiver {

    private static final String FILE = "viec_can_lam";
    private static final String K_JSON = "json";
    private static final String K_MA = "ma_da_dat";
    private static final String ACTION = "vn.tinhthatadida.lichvia.VIEC";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String gio = intent.getStringExtra("gio");
        String nd = intent.getStringExtra("nd");
        int ma = intent.getIntExtra("ma", 3000);
        NhacNho.taoKenh(ctx);
        NhacNho.banTin(ctx, ma, "Việc cần làm · " + (gio == null ? "" : gio),
                nd == null ? "" : nd, new Prefs(ctx).chuong());
    }

    private static SharedPreferences sp(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Luu danh sach viec (JSON tu giao dien) va dat lai toan bo bao thuc. */
    public static void datTatCa(Context ctx, String json) {
        sp(ctx).edit().putString(K_JSON, json == null ? "[]" : json).apply();
        datLai(ctx);
    }

    /** Dat lai bao thuc tu danh sach da luu (goi khi mo app, khoi dong may). */
    public static void datLai(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        SharedPreferences s = sp(ctx);

        // Huy cac bao thuc cu
        String cu = s.getString(K_MA, "");
        if (cu.length() > 0) {
            for (String m : cu.split(",")) {
                try {
                    int ma = Integer.parseInt(m);
                    am.cancel(taoPi(ctx, ma, null, null));
                } catch (Exception ignored) {
                }
            }
        }

        StringBuilder moi = new StringBuilder();
        try {
            JSONArray ds = new JSONArray(s.getString(K_JSON, "[]"));
            long bayGio = System.currentTimeMillis();
            for (int k = 0; k < ds.length(); k++) {
                JSONObject o = ds.getJSONObject(k);
                if (o.optBoolean("xong", false)) continue;
                String ngay = o.optString("ngay", "");
                String gio = o.optString("gio", "07:00");
                String nd = o.optString("nd", "");
                String[] a = ngay.split("-");
                String[] g = gio.split(":");
                if (a.length < 3 || g.length < 2) continue;
                Calendar c = Calendar.getInstance();
                c.set(Integer.parseInt(a[0]), Integer.parseInt(a[1]) - 1, Integer.parseInt(a[2]),
                        Integer.parseInt(g[0]), Integer.parseInt(g[1]), 0);
                c.set(Calendar.MILLISECOND, 0);
                long khi = c.getTimeInMillis();
                if (khi <= bayGio) continue;
                int ma = 3000 + (Math.abs(o.optString("id", String.valueOf(k)).hashCode()) % 90000);
                PendingIntent pi = taoPi(ctx, ma, gio, nd);
                datBaoThuc(am, khi, pi);
                if (moi.length() > 0) moi.append(',');
                moi.append(ma);
            }
        } catch (Exception ignored) {
        }
        s.edit().putString(K_MA, moi.toString()).apply();
    }

    private static PendingIntent taoPi(Context ctx, int ma, String gio, String nd) {
        Intent i = new Intent(ctx, ViecReceiver.class);
        i.setAction(ACTION);
        i.putExtra("ma", ma);
        if (gio != null) i.putExtra("gio", gio);
        if (nd != null) i.putExtra("nd", nd);
        int co = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) co |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(ctx, ma, i, co);
    }

    private static void datBaoThuc(AlarmManager am, long khi, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
                }
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, khi, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, khi, pi);
        }
    }
}
