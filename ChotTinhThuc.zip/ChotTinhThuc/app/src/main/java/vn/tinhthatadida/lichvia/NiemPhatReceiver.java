package vn.tinhthatadida.lichvia;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/** Nhac niem Phat lap lai hang ngay (Cong Cu Niem Phat). */
public class NiemPhatReceiver extends BroadcastReceiver {

    private static final String FILE = "niem_phat";
    private static final String K_JSON = "json";
    private static final String K_MA = "ma_da_dat";
    private static final String ACTION = "vn.tinhthatadida.lichvia.NIEMPHAT";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String gio = intent.getStringExtra("gio");
        String nd = intent.getStringExtra("nd");
        int ma = intent.getIntExtra("ma", 100000);
        NhacNho.taoKenh(ctx);
        NhacNho.banTin(ctx, ma, "Nhắc niệm Phật · " + (gio == null ? "" : gio),
                (nd == null || nd.length() == 0 ? "Nhớ Niệm Phật" : nd) + " — Nam Mô A Di Đà Phật",
                new Prefs(ctx).chuong());
        // Dat lai cho ngay hom sau
        datLai(ctx);
    }

    private static SharedPreferences sp(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Luu cai dat nhac (JSON tu giao dien) va dat lai toan bo bao thuc. */
    public static void datTatCa(Context ctx, String json) {
        sp(ctx).edit().putString(K_JSON, json == null ? "{}" : json).commit();
        datLai(ctx);
    }

    public static String layJson(Context ctx) {
        return sp(ctx).getString(K_JSON, "");
    }

    /** Dat lai bao thuc cho lan nhac ke tiep cua moi loi nhac dang bat. */
    public static void datLai(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        SharedPreferences s = sp(ctx);

        String cu = s.getString(K_MA, "");
        if (cu.length() > 0) {
            for (String m : cu.split(",")) {
                try {
                    am.cancel(taoPi(ctx, Integer.parseInt(m), null, null));
                } catch (Exception ignored) {
                }
            }
        }

        StringBuilder moi = new StringBuilder();
        try {
            JSONObject goc = new JSONObject(s.getString(K_JSON, "{}"));
            if (goc.optBoolean("bat", true)) {
                JSONArray ds = goc.optJSONArray("ds");
                long bayGio = System.currentTimeMillis();
                for (int k = 0; ds != null && k < ds.length(); k++) {
                    JSONObject o = ds.getJSONObject(k);
                    if (!o.optBoolean("bat", true)) continue;
                    String gio = o.optString("gio", "07:00");
                    String nd = o.optString("nd", "Nhớ Niệm Phật");
                    String[] g = gio.split(":");
                    if (g.length < 2) continue;
                    Calendar c = Calendar.getInstance();
                    c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(g[0]));
                    c.set(Calendar.MINUTE, Integer.parseInt(g[1]));
                    c.set(Calendar.SECOND, 0);
                    c.set(Calendar.MILLISECOND, 0);
                    if (c.getTimeInMillis() <= bayGio + 1000) c.add(Calendar.DAY_OF_MONTH, 1);
                    int ma = 100000 + (Math.abs(o.optString("id", String.valueOf(k)).hashCode()) % 90000);
                    datBaoThuc(am, c.getTimeInMillis(), taoPi(ctx, ma, gio, nd));
                    if (moi.length() > 0) moi.append(',');
                    moi.append(ma);
                }
            }
        } catch (Exception ignored) {
        }
        s.edit().putString(K_MA, moi.toString()).commit();
    }

    private static PendingIntent taoPi(Context ctx, int ma, String gio, String nd) {
        Intent i = new Intent(ctx, NiemPhatReceiver.class);
        i.setAction(ACTION);
        i.putExtra("ma", ma);
        if (gio != null) i.putExtra("gio", gio);
        if (nd != null) i.putExtra("nd", nd);
        int co = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) co |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(ctx, ma, i, co);
    }

    private static void datBaoThuc(AlarmManager am, long khi, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
                }
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, khi, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, khi, pi);
        }
    }
}
