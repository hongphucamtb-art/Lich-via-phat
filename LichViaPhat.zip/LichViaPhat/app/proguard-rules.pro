# Giu cac lop duoc tham chieu tu XML va Manifest
-keep class vn.tinhthatadida.lichvia.** { *; }
