package vn.tinhthatadida.lichvia;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Nhan bao thuc hang ngay -> kiem tra va thong bao, roi dat lai cho ngay hom sau. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            NhacNho.kiemTraVaThongBao(context);
        } catch (Exception ignored) {
        }
        NhacNho.datLichNhac(context);
    }
}
