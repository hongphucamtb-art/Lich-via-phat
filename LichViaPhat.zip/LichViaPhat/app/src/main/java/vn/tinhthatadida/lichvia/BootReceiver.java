package vn.tinhthatadida.lichvia;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Dat lai bao thuc sau khi khoi dong may hoac cap nhat app. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        NhacNho.taoKenh(context);
        NhacNho.datLichNhac(context);
    }
}
