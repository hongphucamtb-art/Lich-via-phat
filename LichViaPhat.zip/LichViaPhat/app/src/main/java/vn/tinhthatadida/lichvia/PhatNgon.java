package vn.tinhthatadida.lichvia;

import java.util.Calendar;

/** Loi Phat day — moi ngay mot cau. */
public final class PhatNgon {

    private PhatNgon() {
    }

    public static final String[][] CAU = {
            {"Tâm dẫn đầu các pháp, tâm làm chủ, tâm tạo tác. Nếu nói hay hành động với tâm thanh tịnh, an lạc sẽ theo sau như bóng không rời hình.", "Kinh Pháp Cú, kệ 2"},
            {"Hận thù không thể diệt hận thù, chỉ có tình thương mới diệt được hận thù. Đó là định luật ngàn thu.", "Kinh Pháp Cú, kệ 5"},
            {"Không làm các điều ác, siêng làm các việc lành, giữ tâm ý trong sạch — đó là lời chư Phật dạy.", "Kinh Pháp Cú, kệ 183"},
            {"Chiến thắng vạn quân không bằng tự thắng mình. Tự thắng mình là chiến công oanh liệt nhất.", "Kinh Pháp Cú, kệ 103"},
            {"Người trí chế ngự tâm mình như thợ làm tên uốn thẳng mũi tên.", "Kinh Pháp Cú, kệ 80"},
            {"Sức khỏe là món quà quý nhất, biết đủ là gia tài lớn nhất, tín cẩn là bà con thân nhất, Niết Bàn là hạnh phúc tối thượng.", "Kinh Pháp Cú, kệ 204"},
            {"Ai sống một trăm năm mà không thấy pháp sinh diệt, không bằng sống một ngày mà thấy được pháp sinh diệt.", "Kinh Pháp Cú, kệ 113"},
            {"Chớ khinh điều thiện nhỏ mà cho rằng không quả báo. Giọt nước tuy nhỏ, dần dần cũng đầy lu.", "Kinh Pháp Cú, kệ 122"},
            {"Nếu có chúng sinh nào nghe danh hiệu Ta mà chuyên tâm niệm, nguyện sinh về nước Ta, khi lâm chung Ta sẽ cùng thánh chúng hiện ra trước mặt tiếp dẫn.", "Kinh A Di Đà — Đại nguyện thứ 18"},
            {"Nếu người muốn rõ biết, tất cả Phật ba đời, nên quán pháp giới tánh, tất cả do tâm tạo.", "Kinh Hoa Nghiêm"},
            {"Chúng sinh vô biên thệ nguyện độ, phiền não vô tận thệ nguyện đoạn, pháp môn vô lượng thệ nguyện học, Phật đạo vô thượng thệ nguyện thành.", "Tứ Hoằng Thệ Nguyện"},
            {"Nhất thiết hữu vi pháp, như mộng huyễn bào ảnh, như lộ diệc như điện, ưng tác như thị quán.", "Kinh Kim Cang"},
            {"Ưng vô sở trụ nhi sinh kỳ tâm — Nên không trụ vào đâu cả mà sinh tâm ấy.", "Kinh Kim Cang"},
            {"Sắc chẳng khác không, không chẳng khác sắc; sắc tức là không, không tức là sắc.", "Bát Nhã Tâm Kinh"},
            {"Địa ngục chưa trống, thề chẳng thành Phật; chúng sinh độ hết, mới chứng Bồ Đề.", "Đại nguyện Địa Tạng Bồ Tát"},
            {"Người nào nghe danh hiệu Quán Thế Âm Bồ Tát, một lòng xưng danh, tức thời Bồ Tát quán âm thanh ấy đều được giải thoát.", "Kinh Pháp Hoa — Phẩm Phổ Môn"},
            {"Ăn chay là nuôi dưỡng lòng từ bi, không nỡ ăn thịt chúng sinh vì chúng cũng biết đau, biết sợ chết như ta.", "Lời dạy nhà Phật"},
            {"Hết thảy chúng sinh đều có Phật tánh, đều có thể thành Phật.", "Kinh Niết Bàn"},
            {"Giữ giới như giữ tròng mắt, phá giới thì mất tất cả công đức.", "Kinh Phạm Võng"},
            {"Ba nghiệp thân, khẩu, ý thanh tịnh thì mọi việc đều thanh tịnh.", "Lời dạy nhà Phật"},
            {"Tội từ tâm khởi đem tâm sám, tâm được tịnh rồi tội liền tiêu.", "Kệ Sám Hối"},
            {"Nguyện đem công đức này, hướng về khắp tất cả, đệ tử và chúng sinh, đều trọn thành Phật đạo.", "Kệ Hồi Hướng"},
            {"Một câu A Di Đà Phật, niệm đến cùng thì phiền não tự tiêu, trí tuệ tự sáng.", "Tổ Ấn Quang"},
            {"Người niệm Phật nên lấy tâm chân thành, tâm thanh tịnh, tâm bình đẳng làm gốc.", "Tổ Ấn Quang"},
            {"Hiếu thảo với cha mẹ là phước điền lớn nhất ở đời.", "Kinh Tăng Chi"},
            {"Cha mẹ tại tiền như Phật tại thế.", "Kinh Vu Lan"},
            {"Sân hận là ngọn lửa đốt cháy rừng công đức.", "Luận Đại Trí Độ"},
            {"Người biết đủ tuy nằm dưới đất vẫn thấy an vui; người không biết đủ dù ở thiên đường cũng chẳng vừa lòng.", "Kinh Di Giáo"},
            {"Các con hãy tự mình thắp đuốc lên mà đi, hãy nương tựa nơi chính mình và nương tựa nơi Chánh pháp.", "Kinh Đại Bát Niết Bàn"},
            {"Này các Tỳ kheo, hãy tinh tấn lên, các pháp hữu vi đều vô thường.", "Lời cuối của Đức Phật"},
            {"Thân người khó được, Phật pháp khó nghe. Nay đã được thân người, đã nghe Phật pháp, chớ để luống qua.", "Lời dạy nhà Phật"},
            {"Tha thứ cho người là giải thoát chính mình.", "Lời dạy nhà Phật"},
            {"Bố thí, ái ngữ, lợi hành, đồng sự — bốn nhiếp pháp nhiếp phục lòng người.", "Kinh Tăng Chi"},
            {"Ít muốn, biết đủ, sống đơn giản — đó là con đường an lạc.", "Kinh Di Giáo"},
            {"Nói lời chân thật, dịu dàng, đúng lúc, có ích — đó là chánh ngữ.", "Bát Chánh Đạo"},
            {"Mỗi hơi thở chánh niệm là một bước chân trên đường về Cực Lạc.", "Lời dạy nhà Phật"},
            {"Từ bi không phải là yếu đuối, đó là sức mạnh lớn nhất của tâm hồn.", "Lời dạy nhà Phật"},
            {"Cúng dường Tam Bảo, cung kính Tăng Ni, gieo phước đời đời.", "Lời dạy nhà Phật"},
            {"Giữ một ngày trai giới, phước đức vô lượng, tâm được thanh lương.", "Kinh Bát Quan Trai"},
            {"Niệm Phật một câu, phước sinh vô lượng; lễ Phật một lạy, tội diệt hà sa.", "Cổ đức"},
    };

    /** Cau Phat ngon cua ngay — cung mot ngay luon ra cung mot cau. */
    public static String[] cuaNgay(Calendar c) {
        long jd = AmLich.jdFromDate(c.get(Calendar.DAY_OF_MONTH),
                c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR));
        int i = (int) (((jd % CAU.length) + CAU.length) % CAU.length);
        return CAU[i];
    }
}
