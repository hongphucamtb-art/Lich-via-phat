package vn.tinhthatadida.lichvia;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Calendar;

/** Luu tru cai dat va du lieu ca nhan cua Phat tu. */
public class Prefs {

    private static final String FILE = "tinhthat_adida";

    public static final String KEY_TEN = "ten";
    public static final String KEY_PHAP_DANH = "phap_danh";
    public static final String KEY_CHE_DO_CHAY = "che_do_chay";
    public static final String KEY_NHAC_TRUOC = "nhac_truoc";      // so ngay 0..7
    public static final String KEY_GIO_NHAC = "gio_nhac";          // 0..23
    public static final String KEY_PHUT_NHAC = "phut_nhac";        // 0..59
    public static final String KEY_NHAC_NGAY_TRAI = "nhac_ngay_trai";
    public static final String KEY_NHAC_NGAY_VIA = "nhac_ngay_via";
    public static final String KEY_CHUONG = "chuong";
    public static final String KEY_DA_CHAO = "da_chao";
    public static final String KEY_NGAY_CHAY = "ngay_chay_";       // + yyyyMMdd

    private final SharedPreferences sp;

    public Prefs(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public String ten() {
        return sp.getString(KEY_TEN, "");
    }

    public void setTen(String v) {
        sp.edit().putString(KEY_TEN, v == null ? "" : v.trim()).apply();
    }

    public String phapDanh() {
        return sp.getString(KEY_PHAP_DANH, "");
    }

    public void setPhapDanh(String v) {
        sp.edit().putString(KEY_PHAP_DANH, v == null ? "" : v.trim()).apply();
    }

    /** Ten hien thi uu tien phap danh. */
    public String tenHienThi() {
        String pd = phapDanh();
        if (pd.length() > 0) return pd;
        String t = ten();
        return t.length() > 0 ? t : "";
    }

    public String loiChao() {
        String t = tenHienThi();
        if (t.length() == 0) return "Kính chào quý Phật tử";
        return "Kính chào Phật tử " + t;
    }

    public int cheDoChay() {
        return sp.getInt(KEY_CHE_DO_CHAY, NgayLe.CHAY_THAP_TRAI);
    }

    public void setCheDoChay(int v) {
        sp.edit().putInt(KEY_CHE_DO_CHAY, v).apply();
    }

    public int nhacTruoc() {
        return sp.getInt(KEY_NHAC_TRUOC, 1);
    }

    public void setNhacTruoc(int v) {
        sp.edit().putInt(KEY_NHAC_TRUOC, v).apply();
    }

    public int gioNhac() {
        return sp.getInt(KEY_GIO_NHAC, 19);
    }

    public int phutNhac() {
        return sp.getInt(KEY_PHUT_NHAC, 0);
    }

    public void setGioNhac(int gio, int phut) {
        sp.edit().putInt(KEY_GIO_NHAC, gio).putInt(KEY_PHUT_NHAC, phut).apply();
    }

    public boolean nhacNgayTrai() {
        return sp.getBoolean(KEY_NHAC_NGAY_TRAI, true);
    }

    public void setNhacNgayTrai(boolean v) {
        sp.edit().putBoolean(KEY_NHAC_NGAY_TRAI, v).apply();
    }

    public boolean nhacNgayVia() {
        return sp.getBoolean(KEY_NHAC_NGAY_VIA, true);
    }

    public void setNhacNgayVia(boolean v) {
        sp.edit().putBoolean(KEY_NHAC_NGAY_VIA, v).apply();
    }

    public boolean chuong() {
        return sp.getBoolean(KEY_CHUONG, true);
    }

    public void setChuong(boolean v) {
        sp.edit().putBoolean(KEY_CHUONG, v).apply();
    }

    public boolean daChao() {
        return sp.getBoolean(KEY_DA_CHAO, false);
    }

    public void setDaChao(boolean v) {
        sp.edit().putBoolean(KEY_DA_CHAO, v).apply();
    }

    // ---- Nhat ky an chay ----
    private static String khoaNgay(Calendar c) {
        return KEY_NGAY_CHAY + c.get(Calendar.YEAR) * 10000
                + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH);
    }

    public boolean daAnChay(Calendar c) {
        return sp.getBoolean(khoaNgay(c), false);
    }

    public void danhDauAnChay(Calendar c, boolean v) {
        if (v) sp.edit().putBoolean(khoaNgay(c), true).apply();
        else sp.edit().remove(khoaNgay(c)).apply();
    }

    /** Dem so ngay da an chay trong thang duong lich cua c. */
    public int soNgayChayTrongThang(Calendar c) {
        Calendar t = (Calendar) c.clone();
        int max = t.getActualMaximum(Calendar.DAY_OF_MONTH);
        int dem = 0;
        for (int d = 1; d <= max; d++) {
            t.set(Calendar.DAY_OF_MONTH, d);
            if (daAnChay(t)) dem++;
        }
        return dem;
    }

    /** Dem so ngay da an chay trong nam duong lich cua c. */
    public int soNgayChayTrongNam(Calendar c) {
        Calendar t = (Calendar) c.clone();
        t.set(Calendar.DAY_OF_YEAR, 1);
        int max = t.getActualMaximum(Calendar.DAY_OF_YEAR);
        int dem = 0;
        for (int d = 1; d <= max; d++) {
            t.set(Calendar.DAY_OF_YEAR, d);
            if (daAnChay(t)) dem++;
        }
        return dem;
    }

    /** So ngay an chay lien tiep tinh den hom nay. */
    public int chuoiLienTiep(Calendar homNay) {
        Calendar t = (Calendar) homNay.clone();
        int dem = 0;
        if (!daAnChay(t)) {
            t.add(Calendar.DAY_OF_MONTH, -1);
            if (!daAnChay(t)) return 0;
        }
        while (daAnChay(t) && dem < 3660) {
            dem++;
            t.add(Calendar.DAY_OF_MONTH, -1);
        }
        return dem;
    }
}
