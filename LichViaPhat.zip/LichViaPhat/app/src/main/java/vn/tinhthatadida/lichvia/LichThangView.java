package vn.tinhthatadida.lichvia;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.Calendar;
import java.util.List;

/** Lich thang duong lich kem ngay am, danh dau ngay trai va ngay via. */
public class LichThangView extends View {

    public interface OnChonNgay {
        void chon(Calendar ngay);
    }

    private static final String[] DAU_TUAN = {"CN", "T2", "T3", "T4", "T5", "T6", "T7"};

    private final Paint pNen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pDuong = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pAm = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pTuan = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pCham = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF o = new RectF();

    private int nam, thang;              // duong lich dang xem
    private Calendar ngayChon;
    private OnChonNgay callback;
    private int cheDoChay = NgayLe.CHAY_THAP_TRAI;

    private int soO;                     // so o hien thi
    private int batDauTuan;              // vi tri ngay 1
    private int soNgayThang;
    private int soHang;

    private final int[] traiCache = new int[42];   // 1 = ngay trai
    private final int[] viaCache = new int[42];    // 1 = ngay via, 2 = trong dai
    private final int[] amNgay = new int[42];
    private final int[] amThang = new int[42];
    private final boolean[] amDauThang = new boolean[42];

    private float dp;

    public LichThangView(Context c) {
        super(c);
        init();
    }

    public LichThangView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        dp = getResources().getDisplayMetrics().density;
        pDuong.setTextAlign(Paint.Align.CENTER);
        pDuong.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        pAm.setTextAlign(Paint.Align.CENTER);
        pTuan.setTextAlign(Paint.Align.CENTER);
        pTuan.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        Calendar t = AmLich.homNay();
        nam = t.get(Calendar.YEAR);
        thang = t.get(Calendar.MONTH) + 1;
        ngayChon = (Calendar) t.clone();
        tinhLai();
    }

    public void setCallback(OnChonNgay cb) {
        callback = cb;
    }

    public void setCheDoChay(int cd) {
        cheDoChay = cd;
        tinhLai();
        invalidate();
    }

    public void doiThang(int delta) {
        thang += delta;
        while (thang > 12) {
            thang -= 12;
            nam++;
        }
        while (thang < 1) {
            thang += 12;
            nam--;
        }
        tinhLai();
        invalidate();
    }

    public void veThang(int n, int t) {
        nam = n;
        thang = t;
        tinhLai();
        invalidate();
    }

    public int getNam() {
        return nam;
    }

    public int getThang() {
        return thang;
    }

    public Calendar getNgayChon() {
        return ngayChon;
    }

    public void setNgayChon(Calendar c) {
        ngayChon = (Calendar) c.clone();
        if (ngayChon.get(Calendar.YEAR) != nam || ngayChon.get(Calendar.MONTH) + 1 != thang) {
            nam = ngayChon.get(Calendar.YEAR);
            thang = ngayChon.get(Calendar.MONTH) + 1;
            tinhLai();
        }
        invalidate();
    }

    /** Mo ta am lich cua thang dang xem, vi du "Tháng 6 - Tháng 7 (Bính Ngọ)". */
    public String moTaAmLich() {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(nam, thang - 1, 1);
        AmLich.Ngay a = AmLich.duongSangAm(1, thang, nam);
        c.set(nam, thang - 1, soNgayThang);
        AmLich.Ngay b = AmLich.duongSangAm(soNgayThang, thang, nam);
        String s = "Âm lịch: tháng " + a.tenThang();
        if (b.thang != a.thang) s += " - " + b.tenThang();
        s += " năm " + a.canChiNam();
        return s;
    }

    private void tinhLai() {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(nam, thang - 1, 1);
        batDauTuan = c.get(Calendar.DAY_OF_WEEK) - 1; // 0 = CN
        soNgayThang = c.getActualMaximum(Calendar.DAY_OF_MONTH);
        soHang = (int) Math.ceil((batDauTuan + soNgayThang) / 7.0);
        soO = soHang * 7;

        for (int i = 0; i < 42; i++) {
            traiCache[i] = 0;
            viaCache[i] = 0;
            amNgay[i] = 0;
            amThang[i] = 0;
            amDauThang[i] = false;
        }
        for (int d = 1; d <= soNgayThang; d++) {
            int i = batDauTuan + d - 1;
            if (i < 0 || i >= 42) continue;
            AmLich.Ngay a = AmLich.duongSangAm(d, thang, nam);
            amNgay[i] = a.ngay;
            amThang[i] = a.thang;
            amDauThang[i] = (a.ngay == 1);
            traiCache[i] = NgayLe.laNgayTrai(a, cheDoChay) ? 1 : 0;
            List<NgayLe> les = NgayLe.vaoNgay(a);
            if (!les.isEmpty()) {
                viaCache[i] = 1;
                for (NgayLe l : les) {
                    if (l.laTrongDai()) viaCache[i] = 2;
                }
            }
        }
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        float oW = w / 7f;
        float oH = oW * 0.92f;
        int h = (int) (oH * soHang + 26 * dp);
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth();
        float oW = w / 7f;
        float oH = oW * 0.92f;
        float topTuan = 18 * dp;

        // hang thu trong tuan
        pTuan.setTextSize(11 * dp);
        for (int i = 0; i < 7; i++) {
            pTuan.setColor(i == 0 ? 0xFFC0392B : 0xFF8B6B3D);
            cv.drawText(DAU_TUAN[i], oW * i + oW / 2, topTuan - 4 * dp, pTuan);
        }
        pNen.setColor(0x33B8860B);
        cv.drawRect(6 * dp, topTuan, w - 6 * dp, topTuan + 1 * dp, pNen);

        Calendar hn = AmLich.homNay();
        boolean cungThangHN = hn.get(Calendar.YEAR) == nam && hn.get(Calendar.MONTH) + 1 == thang;
        int ngayHN = hn.get(Calendar.DAY_OF_MONTH);
        boolean cungThangChon = ngayChon != null
                && ngayChon.get(Calendar.YEAR) == nam
                && ngayChon.get(Calendar.MONTH) + 1 == thang;
        int ngayChonSo = cungThangChon ? ngayChon.get(Calendar.DAY_OF_MONTH) : -1;

        for (int i = 0; i < soO; i++) {
            int d = i - batDauTuan + 1;
            if (d < 1 || d > soNgayThang) continue;
            int hang = i / 7;
            int cot = i % 7;
            float cx = oW * cot + oW / 2;
            float cy = topTuan + oH * hang + oH / 2;
            float r = Math.min(oW, oH) / 2f - 3 * dp;

            boolean laHomNay = cungThangHN && d == ngayHN;
            boolean laChon = d == ngayChonSo;

            // nen ngay trai
            if (traiCache[i] == 1) {
                pNen.setColor(0x2E4CAF50);
                cv.drawCircle(cx, cy, r, pNen);
            }
            // vien ngay via
            if (viaCache[i] > 0) {
                pNen.setColor(viaCache[i] == 2 ? 0xFFB8860B : 0x66B8860B);
                pNen.setStyle(Paint.Style.STROKE);
                pNen.setStrokeWidth(viaCache[i] == 2 ? 2f * dp : 1.2f * dp);
                cv.drawCircle(cx, cy, r, pNen);
                pNen.setStyle(Paint.Style.FILL);
            }
            // hom nay
            if (laHomNay) {
                pNen.setColor(0xFF7B1E1E);
                cv.drawCircle(cx, cy, r, pNen);
            } else if (laChon) {
                pNen.setColor(0x337B1E1E);
                cv.drawCircle(cx, cy, r, pNen);
            }

            // so duong lich
            pDuong.setTextSize(15 * dp);
            if (laHomNay) pDuong.setColor(0xFFFFF3D6);
            else if (cot == 0) pDuong.setColor(0xFFC0392B);
            else if (viaCache[i] == 2) pDuong.setColor(0xFF8A5A00);
            else pDuong.setColor(0xFF3B2E20);
            cv.drawText(String.valueOf(d), cx, cy + 1 * dp, pDuong);

            // so am lich
            pAm.setTextSize(9.5f * dp);
            if (laHomNay) pAm.setColor(0xCCFFE9B0);
            else if (amDauThang[i]) pAm.setColor(0xFFB8860B);
            else pAm.setColor(0xFF9A8B78);
            String sAm = amDauThang[i] ? ("1/" + amThang[i]) : String.valueOf(amNgay[i]);
            cv.drawText(sAm, cx, cy + 13 * dp, pAm);

            // cham danh dau ngay trai
            if (traiCache[i] == 1) {
                pCham.setColor(0xFF4CAF50);
                cv.drawCircle(cx, cy - r + 4.5f * dp, 2.2f * dp, pCham);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP) {
            float oW = getWidth() / 7f;
            float oH = oW * 0.92f;
            float topTuan = 18 * getResources().getDisplayMetrics().density;
            int cot = (int) (e.getX() / oW);
            int hang = (int) ((e.getY() - topTuan) / oH);
            if (cot < 0) cot = 0;
            if (cot > 6) cot = 6;
            if (hang < 0) return true;
            int i = hang * 7 + cot;
            int d = i - batDauTuan + 1;
            if (d >= 1 && d <= soNgayThang) {
                Calendar c = Calendar.getInstance();
                c.clear();
                c.set(nam, thang - 1, d);
                ngayChon = c;
                invalidate();
                if (callback != null) callback.chon((Calendar) c.clone());
            }
            return true;
        }
        return true;
    }
}
