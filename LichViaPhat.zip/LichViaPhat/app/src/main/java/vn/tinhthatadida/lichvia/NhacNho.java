package vn.tinhthatadida.lichvia;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;
import java.util.List;

/** Dat lich va phat thong bao nhac nho an chay / ngay via. */
public final class NhacNho {

    public static final String KENH_ID = "nhac_ngay_le";
    public static final String KENH_TEN = "Nhắc ngày trai và ngày vía";
    public static final int MA_ALARM = 1001;
    private static final int ID_TB_GOC = 2000;

    private NhacNho() {
    }

    public static void taoKenh(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm =
                (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel kenh = new NotificationChannel(
                KENH_ID, KENH_TEN, NotificationManager.IMPORTANCE_HIGH);
        kenh.setDescription("Nhắc trước các ngày ăn chay, ngày vía chư Phật, Bồ Tát");
        kenh.enableLights(true);
        kenh.enableVibration(true);
        nm.createNotificationChannel(kenh);
    }

    /** Dat bao thuc hang ngay vao gio Phat tu chon. */
    public static void datLichNhac(Context ctx) {
        Prefs p = new Prefs(ctx);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent i = new Intent(ctx, AlarmReceiver.class);
        i.setAction("vn.tinhthatadida.lichvia.NHAC");
        int co = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            co |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getBroadcast(ctx, MA_ALARM, i, co);

        if (!p.nhacNgayTrai() && !p.nhacNgayVia()) {
            am.cancel(pi);
            return;
        }

        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, p.gioNhac());
        c.set(Calendar.MINUTE, p.phutNhac());
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) {
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        long khi = c.getTimeInMillis();

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, khi, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, khi, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, khi, pi);
        }
    }

    /** Kiem tra cac ngay sap toi va phat thong bao neu can. */
    public static void kiemTraVaThongBao(Context ctx) {
        Prefs p = new Prefs(ctx);
        taoKenh(ctx);

        int truoc = p.nhacTruoc();          // 0..7
        Calendar homNay = AmLich.homNay();

        int idx = 0;
        for (int d = 0; d <= truoc; d++) {
            Calendar c = (Calendar) homNay.clone();
            c.add(Calendar.DAY_OF_MONTH, d);
            AmLich.Ngay am = AmLich.duongSangAm(c.get(Calendar.DAY_OF_MONTH),
                    c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR));
            boolean trai = NgayLe.laNgayTrai(am, p.cheDoChay());
            List<NgayLe> les = NgayLe.vaoNgay(am);

            // Chi nhac dung moc "truoc d ngay" va moc ngay hom do
            boolean nhac = (d == truoc) || (d == 0);
            if (!nhac) continue;

            String khiNao;
            if (d == 0) khiNao = "Hôm nay";
            else if (d == 1) khiNao = "Ngày mai";
            else khiNao = "Còn " + d + " ngày nữa";

            if (p.nhacNgayVia() && !les.isEmpty()) {
                NgayLe l = les.get(0);
                String td = khiNao + " — " + l.ten;
                StringBuilder nd = new StringBuilder();
                nd.append(am.moTaNgan()).append(" âm lịch. ");
                if (trai) nd.append("Ngày trai, xin phát tâm ăn chay. ");
                nd.append(l.moTa);
                banTin(ctx, ID_TB_GOC + (idx++), td, nd.toString(), p.chuong());
            } else if (p.nhacNgayTrai() && trai) {
                String td = khiNao + " là ngày trai — xin nhớ ăn chay";
                String nd = am.moTaNgan() + " âm lịch. Giữ một ngày trai giới, "
                        + "phước đức vô lượng, tâm được thanh lương. Nam mô A Di Đà Phật.";
                banTin(ctx, ID_TB_GOC + (idx++), td, nd, p.chuong());
            }
        }
    }

    public static void banTin(Context ctx, int id, String tieuDe, String noiDung, boolean chuong) {
        NotificationManager nm =
                (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Intent mo = new Intent(ctx, MainActivity.class);
        mo.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int co = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            co |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getActivity(ctx, id, mo, co);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            b = new Notification.Builder(ctx, KENH_ID);
        } else {
            b = new Notification.Builder(ctx);
            if (chuong) {
                Uri am = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                b.setSound(am);
            }
        }
        b.setSmallIcon(R.drawable.ic_thong_bao)
                .setContentTitle(tieuDe)
                .setContentText(noiDung)
                .setStyle(new Notification.BigTextStyle().bigText(noiDung))
                .setAutoCancel(true)
                .setContentIntent(pi);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            b.setColor(0xFFB8860B);
        }
        try {
            nm.notify(id, b.build());
        } catch (SecurityException ignored) {
        }
    }
}
