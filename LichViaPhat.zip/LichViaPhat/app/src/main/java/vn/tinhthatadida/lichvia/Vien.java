package vn.tinhthatadida.lichvia;

import android.graphics.Insets;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

/**
 * Xu ly vien man hinh (thanh trang thai, thanh dieu huong, tai tho).
 * Tu Android 15 (targetSdk 35+) ung dung luon tran vien nen phai tu chua le.
 */
public final class Vien {

    private Vien() {
    }

    /**
     * @param goc   view goc cua man hinh (nhan le trai/phai)
     * @param tren  view can chua le tren (co the null)
     * @param duoi  view can chua le duoi (co the null)
     */
    public static void apVien(final View goc, final View tren, final View duoi) {
        if (goc == null) return;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;

        final int gocTren = (tren != null) ? tren.getPaddingTop() : 0;
        final int gocDuoi = (duoi != null) ? duoi.getPaddingBottom() : 0;
        final int gocGocTren = goc.getPaddingTop();
        final int gocGocDuoi = goc.getPaddingBottom();

        goc.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int t, b, l, r;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Insets i = insets.getInsets(
                            WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    t = i.top;
                    b = i.bottom;
                    l = i.left;
                    r = i.right;
                } else {
                    t = insets.getSystemWindowInsetTop();
                    b = insets.getSystemWindowInsetBottom();
                    l = insets.getSystemWindowInsetLeft();
                    r = insets.getSystemWindowInsetRight();
                }
                if (tren != null) {
                    tren.setPadding(tren.getPaddingLeft(), gocTren + t,
                            tren.getPaddingRight(), tren.getPaddingBottom());
                }
                if (duoi != null) {
                    duoi.setPadding(duoi.getPaddingLeft(), duoi.getPaddingTop(),
                            duoi.getPaddingRight(), gocDuoi + b);
                }
                goc.setPadding(l,
                        (tren == null) ? gocGocTren + t : gocGocTren,
                        r,
                        (duoi == null) ? gocGocDuoi + b : gocGocDuoi);
                return insets;
            }
        });
        goc.requestApplyInsets();
    }
}
