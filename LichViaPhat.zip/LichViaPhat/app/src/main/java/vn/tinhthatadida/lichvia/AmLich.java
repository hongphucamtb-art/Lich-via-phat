package vn.tinhthatadida.lichvia;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * Chuyen doi Duong lich <-> Am lich Viet Nam (mui gio UTC+7).
 * Thuat toan theo Ho Ngoc Duc, viet lai thuan Java, khong phu thuoc thu vien.
 */
public final class AmLich {

    public static final double TIMEZONE = 7.0;

    public static final String[] CAN = {"Giáp", "Ất", "Bính", "Đinh", "Mậu",
            "Kỷ", "Canh", "Tân", "Nhâm", "Quý"};
    public static final String[] CHI = {"Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ",
            "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"};
    public static final String[] THU = {"Chủ nhật", "Thứ hai", "Thứ ba",
            "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"};

    private AmLich() {
    }

    /** Ket qua doi lich. */
    public static final class Ngay {
        public int ngay;      // ngay am
        public int thang;     // thang am
        public int nam;       // nam am
        public boolean nhuan; // thang nhuan hay khong
        public int soNgayTrongThang; // 29 hoac 30

        public Ngay(int ngay, int thang, int nam, boolean nhuan) {
            this.ngay = ngay;
            this.thang = thang;
            this.nam = nam;
            this.nhuan = nhuan;
        }

        public String tenThang() {
            switch (thang) {
                case 1: return "Giêng";
                case 11: return "Một";
                case 12: return "Chạp";
                default: return String.valueOf(thang);
            }
        }

        public String tenNgay() {
            if (ngay <= 10) return "Mùng " + ngay;
            return String.valueOf(ngay);
        }

        public String canChiNam() {
            return AmLich.canChiNam(nam);
        }

        public String moTaNgan() {
            return tenNgay() + "/" + tenThang() + (nhuan ? " (nhuận)" : "");
        }

        public String moTaDay() {
            return "Ngày " + ngay + " tháng " + tenThang() + (nhuan ? " (nhuận)" : "")
                    + " năm " + canChiNam();
        }
    }

    private static long INT(double d) {
        return (long) Math.floor(d);
    }

    /** So ngay Julian tu ngay duong lich. */
    public static long jdFromDate(int dd, int mm, int yy) {
        long a = (14 - mm) / 12;
        long y = yy + 4800 - a;
        long m = mm + 12 * a - 3;
        long jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045;
        if (jd < 2299161) {
            jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - 32083;
        }
        return jd;
    }

    /** Ngay duong lich tu so ngay Julian. Tra ve {dd, mm, yyyy}. */
    public static int[] jdToDate(long jd) {
        long a, b, c, d, e, m, day, month, year;
        if (jd > 2299160) {
            a = jd + 32044;
            b = (4 * a + 3) / 146097;
            c = a - (b * 146097) / 4;
        } else {
            b = 0;
            c = jd + 32082;
        }
        d = (4 * c + 3) / 1461;
        e = c - (1461 * d) / 4;
        m = (5 * e + 2) / 153;
        day = e - (153 * m + 2) / 5 + 1;
        month = m + 3 - 12 * (m / 10);
        year = b * 100 + d - 4800 + m / 10;
        return new int[]{(int) day, (int) month, (int) year};
    }

    private static double getNewMoonDayD(int k) {
        double T = k / 1236.85;
        double T2 = T * T;
        double T3 = T2 * T;
        double dr = Math.PI / 180;
        double Jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * T2 - 0.000000155 * T3;
        Jd1 = Jd1 + 0.00033 * Math.sin((166.56 + 132.87 * T - 0.009173 * T2) * dr);
        double M = 359.2242 + 29.10535608 * k - 0.0000333 * T2 - 0.00000347 * T3;
        double Mpr = 306.0253 + 385.81691806 * k + 0.0107306 * T2 + 0.00001236 * T3;
        double F = 21.2964 + 390.67050646 * k - 0.0016528 * T2 - 0.00000239 * T3;
        double C1 = (0.1734 - 0.000393 * T) * Math.sin(M * dr) + 0.0021 * Math.sin(2 * dr * M);
        C1 = C1 - 0.4068 * Math.sin(Mpr * dr) + 0.0161 * Math.sin(dr * 2 * Mpr);
        C1 = C1 - 0.0004 * Math.sin(dr * 3 * Mpr);
        C1 = C1 + 0.0104 * Math.sin(dr * 2 * F) - 0.0051 * Math.sin(dr * (M + Mpr));
        C1 = C1 - 0.0074 * Math.sin(dr * (M - Mpr)) + 0.0004 * Math.sin(dr * (2 * F + M));
        C1 = C1 - 0.0004 * Math.sin(dr * (2 * F - M)) - 0.0006 * Math.sin(dr * (2 * F + Mpr));
        C1 = C1 + 0.0010 * Math.sin(dr * (2 * F - Mpr)) + 0.0005 * Math.sin(dr * (2 * Mpr + M));
        double deltat;
        if (T < -11) {
            deltat = 0.001 + 0.000839 * T + 0.0002261 * T2 - 0.00000845 * T3 - 0.000000081 * T * T3;
        } else {
            deltat = -0.000278 + 0.000265 * T + 0.000262 * T2;
        }
        return Jd1 + C1 - deltat;
    }

    private static long getNewMoonDay(int k, double timeZone) {
        return INT(getNewMoonDayD(k) + 0.5 + timeZone / 24.0);
    }

    private static int getSunLongitude(long jdn, double timeZone) {
        double T = (jdn - 2451545.5 - timeZone / 24.0) / 36525.0;
        double T2 = T * T;
        double dr = Math.PI / 180;
        double M = 357.52910 + 35999.05030 * T - 0.0001559 * T2 - 0.00000048 * T * T2;
        double L0 = 280.46645 + 36000.76983 * T + 0.0003032 * T2;
        double DL = (1.914600 - 0.004817 * T - 0.000014 * T2) * Math.sin(dr * M);
        DL = DL + (0.019993 - 0.000101 * T) * Math.sin(dr * 2 * M) + 0.000290 * Math.sin(dr * 3 * M);
        double L = L0 + DL;
        L = L * dr;
        L = L - Math.PI * 2 * (INT(L / (Math.PI * 2)));
        return (int) INT(L / Math.PI * 6);
    }

    private static long getLunarMonth11(int yy, double timeZone) {
        double off = jdFromDate(31, 12, yy) - 2415021.076998695;
        int k = (int) INT(off / 29.530588853);
        long nm = getNewMoonDay(k, timeZone);
        int sunLong = getSunLongitude(nm, timeZone);
        if (sunLong >= 9) {
            nm = getNewMoonDay(k - 1, timeZone);
        }
        return nm;
    }

    private static int getLeapMonthOffset(long a11, double timeZone) {
        int k = (int) INT((a11 - 2415021.076998695) / 29.530588853 + 0.5);
        int last;
        int i = 1;
        int arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone);
        do {
            last = arc;
            i++;
            arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone);
        } while (arc != last && i < 14);
        return i - 1;
    }

    /** Doi ngay duong lich sang am lich. */
    public static Ngay duongSangAm(int dd, int mm, int yy) {
        return duongSangAm(dd, mm, yy, TIMEZONE);
    }

    public static Ngay duongSangAm(int dd, int mm, int yy, double timeZone) {
        long dayNumber = jdFromDate(dd, mm, yy);
        int k = (int) INT((dayNumber - 2415021.076998695) / 29.530588853);
        long monthStart = getNewMoonDay(k + 1, timeZone);
        int kStart = k + 1;
        if (monthStart > dayNumber) {
            monthStart = getNewMoonDay(k, timeZone);
            kStart = k;
        }
        long monthEnd = getNewMoonDay(kStart + 1, timeZone);
        long a11 = getLunarMonth11(yy, timeZone);
        long b11 = a11;
        int lunarYear;
        if (a11 >= monthStart) {
            lunarYear = yy;
            a11 = getLunarMonth11(yy - 1, timeZone);
        } else {
            lunarYear = yy + 1;
            b11 = getLunarMonth11(yy + 1, timeZone);
        }
        int lunarDay = (int) (dayNumber - monthStart + 1);
        int diff = (int) INT((monthStart - a11) / 29.0);
        boolean lunarLeap = false;
        int lunarMonth = diff + 11;
        if (b11 - a11 > 365) {
            int leapMonthDiff = getLeapMonthOffset(a11, timeZone);
            if (diff >= leapMonthDiff) {
                lunarMonth = diff + 10;
                if (diff == leapMonthDiff) {
                    lunarLeap = true;
                }
            }
        }
        if (lunarMonth > 12) {
            lunarMonth = lunarMonth - 12;
        }
        if (lunarMonth >= 11 && diff < 4) {
            lunarYear -= 1;
        }
        Ngay r = new Ngay(lunarDay, lunarMonth, lunarYear, lunarLeap);
        r.soNgayTrongThang = (int) (monthEnd - monthStart);
        return r;
    }

    /** Doi ngay am lich sang duong lich. Tra ve {dd, mm, yyyy}, hoac null neu khong ton tai. */
    public static int[] amSangDuong(int lunarDay, int lunarMonth, int lunarYear, boolean lunarLeap) {
        return amSangDuong(lunarDay, lunarMonth, lunarYear, lunarLeap, TIMEZONE);
    }

    public static int[] amSangDuong(int lunarDay, int lunarMonth, int lunarYear,
                                    boolean lunarLeap, double timeZone) {
        long a11, b11;
        if (lunarMonth < 11) {
            a11 = getLunarMonth11(lunarYear - 1, timeZone);
            b11 = getLunarMonth11(lunarYear, timeZone);
        } else {
            a11 = getLunarMonth11(lunarYear, timeZone);
            b11 = getLunarMonth11(lunarYear + 1, timeZone);
        }
        int off = lunarMonth - 11;
        if (off < 0) off += 12;
        if (b11 - a11 > 365) {
            int leapOff = getLeapMonthOffset(a11, timeZone);
            int leapMonth = leapOff - 2;
            if (leapMonth < 0) leapMonth += 12;
            if (lunarLeap && lunarMonth != leapMonth) {
                return null;
            } else if (lunarLeap || off >= leapOff) {
                off += 1;
            }
        }
        int k = (int) INT(0.5 + (a11 - 2415021.076998695) / 29.530588853);
        long monthStart = getNewMoonDay(k + off, timeZone);
        return jdToDate(monthStart + lunarDay - 1);
    }

    /** So ngay cua mot thang am lich (29 hoac 30). */
    public static int soNgayThangAm(int lunarMonth, int lunarYear, boolean lunarLeap) {
        int[] d1 = amSangDuong(1, lunarMonth, lunarYear, lunarLeap);
        if (d1 == null) return 30;
        Ngay n = duongSangAm(d1[0], d1[1], d1[2]);
        return n.soNgayTrongThang;
    }

    public static String canChiNam(int nam) {
        return CAN[(nam + 6) % 10] + " " + CHI[(nam + 8) % 12];
    }

    public static String canChiThang(int thang, int nam) {
        return CAN[(nam * 12 + thang + 3) % 10] + " " + CHI[(thang + 1) % 12];
    }

    public static String canChiNgay(int dd, int mm, int yy) {
        long jd = jdFromDate(dd, mm, yy);
        return CAN[(int) ((jd + 9) % 10)] + " " + CHI[(int) ((jd + 1) % 12)];
    }

    /** So ngay chenh lech giua 2 ngay duong lich. */
    public static int khoangCach(Calendar tu, Calendar den) {
        long a = jdFromDate(tu.get(Calendar.DAY_OF_MONTH), tu.get(Calendar.MONTH) + 1,
                tu.get(Calendar.YEAR));
        long b = jdFromDate(den.get(Calendar.DAY_OF_MONTH), den.get(Calendar.MONTH) + 1,
                den.get(Calendar.YEAR));
        return (int) (b - a);
    }

    public static Calendar homNay() {
        Calendar c = Calendar.getInstance(TimeZone.getDefault());
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }
}
