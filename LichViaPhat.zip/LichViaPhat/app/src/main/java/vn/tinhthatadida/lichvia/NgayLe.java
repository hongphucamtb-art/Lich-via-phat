package vn.tinhthatadida.lichvia;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

/**
 * Danh muc cac ngay via, dan sinh, le lon va cac ngay trai trong Phat giao.
 * Ngay ghi theo AM LICH.
 */
public class NgayLe {

    public static final int LOAI_TRONG_DAI = 0; // Dai le trong dai
    public static final int LOAI_VIA = 1;       // Via chu Phat, Bo Tat
    public static final int LOAI_TO_SU = 2;     // To su, Thanh tang
    public static final int LOAI_TRAI = 3;      // Ngay trai (an chay)

    public final int ngayAm;
    public final int thangAm;
    public final String ten;
    public final String moTa;
    public final int loai;

    public NgayLe(int thangAm, int ngayAm, String ten, String moTa, int loai) {
        this.thangAm = thangAm;
        this.ngayAm = ngayAm;
        this.ten = ten;
        this.moTa = moTa;
        this.loai = loai;
    }

    public boolean laTrongDai() {
        return loai == LOAI_TRONG_DAI;
    }

    // ---------------------------------------------------------------
    //  DANH MUC NGAY LE
    // ---------------------------------------------------------------
    private static final NgayLe[] DANH_MUC = {
            // ---- Thang Giêng ----
            new NgayLe(1, 1, "Vía Đức Phật Di Lặc",
                    "Ngày đản sinh Đức Phật Di Lặc — vị Phật tương lai. Cũng là ngày đầu năm mới, "
                            + "Phật tử đi chùa lễ Phật, phát nguyện tu học đầu năm.", LOAI_TRONG_DAI),
            new NgayLe(1, 15, "Rằm Thượng Nguyên",
                    "Rằm tháng Giêng — Tết Nguyên Tiêu. \"Lễ Phật quanh năm không bằng Rằm tháng Giêng\". "
                            + "Ngày cầu an, tụng kinh Dược Sư đầu năm.", LOAI_TRONG_DAI),

            // ---- Thang Hai ----
            new NgayLe(2, 8, "Đức Phật Thích Ca xuất gia",
                    "Thái tử Tất Đạt Đa vượt thành xuất gia tầm đạo, từ bỏ ngôi vua để tìm con đường "
                            + "giải thoát cho muôn loài.", LOAI_TRONG_DAI),
            new NgayLe(2, 15, "Đức Phật Thích Ca nhập Niết Bàn",
                    "Đức Bổn Sư nhập Đại Bát Niết Bàn tại rừng Sa La song thọ, thành Câu Thi Na, "
                            + "thọ 80 tuổi.", LOAI_TRONG_DAI),
            new NgayLe(2, 19, "Vía Quán Thế Âm Bồ Tát đản sinh",
                    "Ngày đản sinh của Đức Quán Thế Âm — vị Bồ Tát của lòng đại từ đại bi, "
                            + "tầm thanh cứu khổ cứu nạn.", LOAI_TRONG_DAI),
            new NgayLe(2, 21, "Vía Phổ Hiền Bồ Tát đản sinh",
                    "Đức Phổ Hiền Bồ Tát — biểu trưng cho hạnh nguyện rộng lớn, Thập Đại Nguyện Vương.",
                    LOAI_VIA),

            // ---- Thang Ba ----
            new NgayLe(3, 6, "Vía Tôn giả Ca Diếp",
                    "Ma Ha Ca Diếp — Đệ nhất Đầu Đà, Sơ Tổ Thiền tông, người kế thừa y bát của "
                            + "Đức Thế Tôn.", LOAI_TO_SU),
            new NgayLe(3, 16, "Vía Chuẩn Đề Bồ Tát",
                    "Đức Chuẩn Đề Bồ Tát — Thất Câu Chi Phật Mẫu, hộ trì người tu hành, tiêu trừ "
                            + "nghiệp chướng.", LOAI_VIA),

            // ---- Thang Tu ----
            new NgayLe(4, 4, "Vía Văn Thù Sư Lợi Bồ Tát",
                    "Đức Văn Thù Bồ Tát — biểu trưng cho trí tuệ bát nhã, tay cầm gươm báu chặt đứt "
                            + "vô minh phiền não.", LOAI_VIA),
            new NgayLe(4, 8, "Đức Phật Thích Ca đản sinh (Bắc tông)",
                    "Ngày Thái tử Tất Đạt Đa giáng sinh tại vườn Lâm Tỳ Ni theo truyền thống Bắc tông. "
                            + "Lễ Tắm Phật được cử hành.", LOAI_TRONG_DAI),
            new NgayLe(4, 15, "ĐẠI LỄ PHẬT ĐẢN — Tam Hợp (Vesak)",
                    "Đại lễ trọng đại nhất trong năm, kỷ niệm ba sự kiện: Đản sinh, Thành đạo và "
                            + "Nhập Niết Bàn của Đức Bổn Sư Thích Ca Mâu Ni Phật.", LOAI_TRONG_DAI),
            new NgayLe(4, 16, "Bắt đầu An cư Kiết hạ",
                    "Chư Tăng Ni nhập hạ an cư ba tháng, chuyên tâm tu học. Phật tử phát tâm cúng "
                            + "dường trường hạ.", LOAI_TO_SU),
            new NgayLe(4, 20, "Vía Bồ Tát Thích Quảng Đức",
                    "Ngày tưởng niệm Bồ Tát Thích Quảng Đức vị pháp thiêu thân, để lại trái tim "
                            + "bất diệt.", LOAI_TO_SU),
            new NgayLe(4, 23, "Vía Phổ Hiền Bồ Tát thành đạo",
                    "Ngày Đức Phổ Hiền Bồ Tát viên thành đạo quả.", LOAI_VIA),
            new NgayLe(4, 28, "Vía Đức Phật Dược Sư đản sinh",
                    "Đức Dược Sư Lưu Ly Quang Vương Phật — giáo chủ cõi Đông Phương Tịnh Lưu Ly, "
                            + "tiêu tai diên thọ, chữa lành thân tâm bệnh.", LOAI_VIA),

            // ---- Thang Nam ----
            new NgayLe(5, 13, "Vía Già Lam Thánh Chúng",
                    "Ngày vía Đức Già Lam Thánh Chúng Bồ Tát — vị hộ pháp gìn giữ chùa chiền, "
                            + "già lam tự viện.", LOAI_VIA),

            // ---- Thang Sau ----
            new NgayLe(6, 3, "Vía Hộ Pháp Vi Đà Bồ Tát",
                    "Đức Vi Đà Hộ Pháp — vị thần hộ trì Chánh pháp, bảo vệ đạo tràng và người tu học.",
                    LOAI_VIA),
            new NgayLe(6, 15, "Ngày Phật chuyển Pháp luân",
                    "Đức Thế Tôn thuyết bài pháp đầu tiên — Tứ Diệu Đế — tại vườn Lộc Uyển độ "
                            + "năm anh em Kiều Trần Như.", LOAI_TRONG_DAI),
            new NgayLe(6, 19, "Vía Quán Thế Âm Bồ Tát thành đạo",
                    "Ngày Đức Quán Thế Âm Bồ Tát viên thành đạo quả, chứng Nhĩ Căn Viên Thông.",
                    LOAI_TRONG_DAI),

            // ---- Thang Bay ----
            new NgayLe(7, 13, "Vía Đại Thế Chí Bồ Tát",
                    "Đức Đại Thế Chí Bồ Tát — một trong Tây Phương Tam Thánh, dùng ánh sáng trí tuệ "
                            + "soi khắp, nhiếp niệm Phật nhân về Tịnh Độ.", LOAI_TRONG_DAI),
            new NgayLe(7, 15, "ĐẠI LỄ VU LAN BÁO HIẾU — Rằm Trung Nguyên",
                    "Ngày Tự Tứ của chư Tăng, ngày Phật hoan hỷ. Phật tử báo hiếu cha mẹ bảy đời, "
                            + "cầu siêu cửu huyền thất tổ theo gương Tôn giả Mục Kiền Liên.", LOAI_TRONG_DAI),
            new NgayLe(7, 30, "Vía Địa Tạng Vương Bồ Tát",
                    "Đức Địa Tạng Bồ Tát — \"Địa ngục vị không, thệ bất thành Phật\". Ngày cầu siêu "
                            + "độ vong linh, hồi hướng cửu huyền thất tổ.", LOAI_TRONG_DAI),

            // ---- Thang Tam ----
            new NgayLe(8, 3, "Vía Lục Tổ Huệ Năng",
                    "Lục Tổ Huệ Năng — vị Tổ thứ sáu Thiền tông Trung Hoa, tác giả Pháp Bảo Đàn Kinh.",
                    LOAI_TO_SU),
            new NgayLe(8, 6, "Vía Sơ Tổ Huệ Viễn",
                    "Đại sư Huệ Viễn — Sơ Tổ Tịnh Độ tông, lập Bạch Liên Xã tại Lô Sơn, "
                            + "khởi xướng pháp môn niệm Phật.", LOAI_TO_SU),
            new NgayLe(8, 8, "Vía Tôn giả A Nan Đà",
                    "Tôn giả A Nan — Đệ nhất Đa Văn, thị giả của Đức Phật, người trùng tuyên "
                            + "toàn bộ Kinh tạng.", LOAI_TO_SU),
            new NgayLe(8, 22, "Vía Đức Phật Nhiên Đăng",
                    "Đức Nhiên Đăng Cổ Phật — vị Phật đã thọ ký cho tiền thân Đức Thích Ca "
                            + "sẽ thành Phật.", LOAI_VIA),

            // ---- Thang Chin ----
            new NgayLe(9, 15, "Ngày Tăng Bảo",
                    "Ngày tưởng niệm và tán thán ngôi Tăng Bảo — chúng trung tôn, người thay Phật "
                            + "hoằng truyền Chánh pháp.", LOAI_TO_SU),
            new NgayLe(9, 19, "Vía Quán Thế Âm Bồ Tát xuất gia",
                    "Ngày Đức Quán Thế Âm Bồ Tát phát tâm xuất gia tu hành.", LOAI_TRONG_DAI),
            new NgayLe(9, 30, "Vía Đức Phật Dược Sư thành đạo",
                    "Ngày Đức Dược Sư Lưu Ly Quang Vương Phật thành tựu đạo quả cùng 12 đại nguyện "
                            + "cứu độ chúng sinh.", LOAI_VIA),

            // ---- Thang Muoi ----
            new NgayLe(10, 5, "Vía Sơ Tổ Bồ Đề Đạt Ma",
                    "Tổ Bồ Đề Đạt Ma — Sơ Tổ Thiền tông Trung Hoa, chín năm diện bích tại Thiếu Lâm.",
                    LOAI_TO_SU),
            new NgayLe(10, 15, "Rằm Hạ Nguyên",
                    "Rằm tháng Mười — lễ tạ ơn Trời Phật, cầu nguyện quốc thái dân an, mùa màng "
                            + "sung túc.", LOAI_TRONG_DAI),

            // ---- Thang Mot (11) ----
            new NgayLe(11, 1, "Phật Hoàng Trần Nhân Tông nhập Niết Bàn",
                    "Đức vua — Phật hoàng Trần Nhân Tông, Sơ Tổ Thiền phái Trúc Lâm Yên Tử, "
                            + "nhập Niết Bàn tại am Ngọa Vân.", LOAI_TO_SU),
            new NgayLe(11, 11, "Ngày sinh Phật Hoàng Trần Nhân Tông",
                    "Kỷ niệm ngày đản sinh Đức vua — Phật hoàng Trần Nhân Tông, người khai sáng "
                            + "Thiền phái Trúc Lâm Việt Nam.", LOAI_TO_SU),
            new NgayLe(11, 17, "VÍA ĐỨC PHẬT A DI ĐÀ",
                    "Ngày vía Đức Phật A Di Đà — giáo chủ cõi Tây Phương Cực Lạc. Ngày trọng đại "
                            + "nhất của người tu Tịnh Độ. Phật tử tinh tấn niệm Phật, phát nguyện "
                            + "vãng sinh. Nam mô A Di Đà Phật.", LOAI_TRONG_DAI),

            // ---- Thang Chap (12) ----
            new NgayLe(12, 8, "Đức Phật Thích Ca thành đạo",
                    "Sau 49 ngày thiền định dưới cội Bồ Đề, Đức Thế Tôn chứng quả Vô Thượng "
                            + "Chánh Đẳng Chánh Giác, khai mở con đường giải thoát cho muôn loài.",
                    LOAI_TRONG_DAI),
            new NgayLe(12, 30, "Lễ Sám hối Giao thừa",
                    "Đêm cuối năm — Phật tử sám hối nghiệp chướng cả năm, phát nguyện tu tập "
                            + "năm mới. (Tháng thiếu thì tính ngày 29)", LOAI_TRONG_DAI),
    };

    public static NgayLe[] tatCa() {
        return DANH_MUC;
    }

    /** Danh sach ngay le trong mot thang am lich. */
    public static List<NgayLe> theoThang(int thangAm) {
        List<NgayLe> kq = new ArrayList<>();
        for (NgayLe n : DANH_MUC) {
            if (n.thangAm == thangAm) kq.add(n);
        }
        return kq;
    }

    /**
     * Cac ngay le roi vao ngay am lich cu the.
     * Xu ly truong hop ngay 30 nhung thang thieu (29 ngay) -> doi ve ngay 29.
     */
    public static List<NgayLe> vaoNgay(AmLich.Ngay am) {
        List<NgayLe> kq = new ArrayList<>();
        for (NgayLe n : DANH_MUC) {
            if (n.thangAm != am.thang || am.nhuan) continue;
            int ngay = n.ngayAm;
            if (ngay == 30 && am.soNgayTrongThang == 29) ngay = 29;
            if (ngay == am.ngay) kq.add(n);
        }
        return kq;
    }

    // ---------------------------------------------------------------
    //  NGAY TRAI (an chay)
    // ---------------------------------------------------------------
    public static final int CHAY_NHI_TRAI = 0;  // 2 ngay: mung 1 va 15
    public static final int CHAY_TU_TRAI = 1;   // 4 ngay: 1, 14, 15, 30
    public static final int CHAY_LUC_TRAI = 2;  // 6 ngay: 8, 14, 15, 23, 29, 30
    public static final int CHAY_THAP_TRAI = 3; // 10 ngay
    public static final int CHAY_TRUONG = 4;    // truong chay

    public static final String[] TEN_CHE_DO_CHAY = {
            "Nhị trai (2 ngày)", "Tứ trai (4 ngày)", "Lục trai (6 ngày)",
            "Thập trai (10 ngày)", "Trường chay (mỗi ngày)"
    };

    private static final int[] NHI = {1, 15};
    private static final int[] TU = {1, 14, 15, 30};
    private static final int[] LUC = {8, 14, 15, 23, 29, 30};
    private static final int[] THAP = {1, 8, 14, 15, 18, 23, 24, 28, 29, 30};

    /** Cac ngay trai trong thang, da hieu chinh theo thang du/thieu. */
    public static int[] ngayTraiTrongThang(int cheDo, int soNgayTrongThang) {
        if (cheDo == CHAY_TRUONG) {
            int[] all = new int[soNgayTrongThang];
            for (int i = 0; i < soNgayTrongThang; i++) all[i] = i + 1;
            return all;
        }
        int[] goc;
        switch (cheDo) {
            case CHAY_NHI_TRAI: goc = NHI; break;
            case CHAY_TU_TRAI:  goc = TU; break;
            case CHAY_LUC_TRAI: goc = LUC; break;
            default:            goc = THAP; break;
        }
        if (soNgayTrongThang == 30) {
            return goc.clone();
        }
        // Thang thieu (29 ngay): theo co le, cac ngay cuoi thang lui lai 1 ngay.
        // Thap trai: 28, 29, 30  ->  27, 28, 29
        // Luc trai: 29, 30       ->  28, 29
        int[] kq = new int[goc.length];
        for (int i = 0; i < goc.length; i++) {
            int d = goc[i];
            if (cheDo == CHAY_THAP_TRAI && (d == 28 || d == 29 || d == 30)) d = d - 1;
            else if (cheDo == CHAY_LUC_TRAI && (d == 29 || d == 30)) d = d - 1;
            else if (d == 30) d = 29;
            kq[i] = d;
        }
        return kq;
    }

    public static boolean laNgayTrai(AmLich.Ngay am, int cheDo) {
        int[] ds = ngayTraiTrongThang(cheDo, am.soNgayTrongThang);
        for (int d : ds) if (d == am.ngay) return true;
        return false;
    }

    // ---------------------------------------------------------------
    //  SU KIEN SAP TOI
    // ---------------------------------------------------------------
    public static class SuKien {
        public Calendar duong;      // ngay duong lich
        public AmLich.Ngay am;      // ngay am lich
        public NgayLe le;           // null neu chi la ngay trai
        public boolean ngayTrai;
        public int conBaoNhieuNgay;

        public String tieuDe() {
            return le != null ? le.ten : "Ngày trai — ăn chay";
        }
    }

    /**
     * Liet ke cac su kien tu hom nay den soNgayTruoc ngay toi.
     * @param gomNgayTrai co gom ca ngay trai thuan tuy hay khong
     */
    public static List<SuKien> sapToi(Calendar tuNgay, int soNgayQuet, int cheDoChay,
                                      boolean gomNgayTrai) {
        List<SuKien> kq = new ArrayList<>();
        Calendar c = (Calendar) tuNgay.clone();
        for (int i = 0; i < soNgayQuet; i++) {
            AmLich.Ngay am = AmLich.duongSangAm(c.get(Calendar.DAY_OF_MONTH),
                    c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR));
            boolean trai = laNgayTrai(am, cheDoChay);
            List<NgayLe> les = vaoNgay(am);
            for (NgayLe l : les) {
                SuKien s = new SuKien();
                s.duong = (Calendar) c.clone();
                s.am = am;
                s.le = l;
                s.ngayTrai = trai;
                s.conBaoNhieuNgay = i;
                kq.add(s);
            }
            if (les.isEmpty() && trai && gomNgayTrai) {
                SuKien s = new SuKien();
                s.duong = (Calendar) c.clone();
                s.am = am;
                s.le = null;
                s.ngayTrai = true;
                s.conBaoNhieuNgay = i;
                kq.add(s);
            }
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        Collections.sort(kq, new java.util.Comparator<SuKien>() {
            @Override
            public int compare(SuKien a, SuKien b) {
                return a.conBaoNhieuNgay - b.conBaoNhieuNgay;
            }
        });
        return kq;
    }
}
