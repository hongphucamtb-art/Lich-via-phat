package vn.tinhthatadida.lichvia;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ViewFlipper;

import java.util.Calendar;
import java.util.List;

public class MainActivity extends Activity {

    private Prefs p;
    private ViewFlipper flipper;
    private LichThangView lich;
    private int trangHienTai = 0;

    private final int[] NAV_ID = {R.id.nav0, R.id.nav1, R.id.nav2, R.id.nav3};
    private final int[] ICON_ID = {R.id.icon0, R.id.icon1, R.id.icon2, R.id.icon3};
    private final int[] NHAN_ID = {R.id.nhan0, R.id.nhan1, R.id.nhan2, R.id.nhan3};

    private static final int MAU_CHON = 0xFF7B1E1E;
    private static final int MAU_THUONG = 0xFFA89880;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        p = new Prefs(this);

        flipper = (ViewFlipper) findViewById(R.id.flipper);
        lich = (LichThangView) findViewById(R.id.lichThang);

        Vien.apVien(findViewById(R.id.goc), findViewById(R.id.header),
                findViewById(R.id.thanhNav));

        for (int i = 0; i < 4; i++) {
            final int idx = i;
            findViewById(NAV_ID[i]).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    chuyenTrang(idx);
                }
            });
        }

        catDatTrangLich();
        catDatTrangCaiDat();

        NhacNho.taoKenh(this);
        xinQuyenThongBao();
        NhacNho.datLichNhac(this);

        chuyenTrang(0);

        // Lan dau mo app: moi Phat tu ghi ten va phap danh
        if (!p.daChao()) {
            startActivity(new Intent(this, ChaoMungActivity.class));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        napCaiDat();
        capNhatTrangChu();
        if (lich != null) {
            lich.setCheDoChay(p.cheDoChay());
            capNhatTieuDeLich();
        }
        capNhatDanhSach();
    }

    private void xinQuyenThongBao() {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 77);
                }
            } catch (Exception ignored) {
            }
        }
    }

    // =====================================================================
    //  DIEU HUONG
    // =====================================================================
    private void chuyenTrang(int i) {
        trangHienTai = i;
        flipper.setDisplayedChild(i);
        for (int k = 0; k < 4; k++) {
            ImageView ic = (ImageView) findViewById(ICON_ID[k]);
            TextView tv = (TextView) findViewById(NHAN_ID[k]);
            int mau = (k == i) ? MAU_CHON : MAU_THUONG;
            ic.setColorFilter(mau);
            tv.setTextColor(mau);
            tv.setTypeface(null, (k == i) ? android.graphics.Typeface.BOLD
                    : android.graphics.Typeface.NORMAL);
        }
        if (i == 0) capNhatTrangChu();
        else if (i == 1) {
            lich.setCheDoChay(p.cheDoChay());
            capNhatTieuDeLich();
            hienChiTietNgay(lich.getNgayChon());
        } else if (i == 2) capNhatDanhSach();
        else napCaiDat();
    }

    @Override
    public void onBackPressed() {
        if (trangHienTai != 0) chuyenTrang(0);
        else super.onBackPressed();
    }

    // =====================================================================
    //  TRANG CHU
    // =====================================================================
    private void capNhatTrangChu() {
        Calendar hn = AmLich.homNay();
        AmLich.Ngay am = AmLich.duongSangAm(hn.get(Calendar.DAY_OF_MONTH),
                hn.get(Calendar.MONTH) + 1, hn.get(Calendar.YEAR));

        ((TextView) findViewById(R.id.tvLoiChao)).setText(p.loiChao());
        ((TextView) findViewById(R.id.tvThu))
                .setText(AmLich.THU[hn.get(Calendar.DAY_OF_WEEK) - 1]);
        ((TextView) findViewById(R.id.tvNgayDuong)).setText(
                String.format("%02d/%02d/%d", hn.get(Calendar.DAY_OF_MONTH),
                        hn.get(Calendar.MONTH) + 1, hn.get(Calendar.YEAR)));
        ((TextView) findViewById(R.id.tvNgayAm)).setText(am.moTaDay());
        ((TextView) findViewById(R.id.tvCanChiNgay)).setText("Ngày "
                + AmLich.canChiNgay(hn.get(Calendar.DAY_OF_MONTH),
                hn.get(Calendar.MONTH) + 1, hn.get(Calendar.YEAR))
                + " — tháng " + AmLich.canChiThang(am.thang, am.nam));

        boolean trai = NgayLe.laNgayTrai(am, p.cheDoChay());
        TextView badge = (TextView) findViewById(R.id.tvTrangThaiTrai);
        badge.setVisibility(trai ? View.VISIBLE : View.GONE);
        if (trai) badge.setText("Hôm nay là ngày trai — xin phát tâm ăn chay");

        // ngay le hom nay
        List<NgayLe> les = NgayLe.vaoNgay(am);
        View the = findViewById(R.id.theHomNay);
        if (les.isEmpty()) {
            the.setVisibility(View.GONE);
        } else {
            the.setVisibility(View.VISIBLE);
            StringBuilder ten = new StringBuilder();
            StringBuilder mo = new StringBuilder();
            for (int i = 0; i < les.size(); i++) {
                if (i > 0) {
                    ten.append("\n");
                    mo.append("\n\n");
                }
                ten.append(les.get(i).ten);
                mo.append(les.get(i).moTa);
            }
            ((TextView) findViewById(R.id.tvLeHomNayTieuDe)).setText(ten.toString());
            ((TextView) findViewById(R.id.tvLeHomNayMoTa)).setText(mo.toString());
        }

        // nut an chay
        final Button btn = (Button) findViewById(R.id.btnAnChay);
        capNhatNutAnChay(btn, hn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar t = AmLich.homNay();
                boolean da = p.daAnChay(t);
                p.danhDauAnChay(t, !da);
                capNhatNutAnChay((Button) v, t);
                capNhatThongKe();
                if (!da) {
                    Toast.makeText(MainActivity.this,
                            "Lành thay! Công đức vô lượng. Nam mô A Di Đà Phật",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
        capNhatThongKe();

        String[] pn = PhatNgon.cuaNgay(hn);
        ((TextView) findViewById(R.id.tvPhatNgon)).setText("“" + pn[0] + "”");
        ((TextView) findViewById(R.id.tvNguon)).setText("— " + pn[1]);

        capNhatSapToi();
    }

    private void capNhatNutAnChay(Button btn, Calendar ngay) {
        if (p.daAnChay(ngay)) {
            btn.setText("✓  Hôm nay con đã ăn chay");
            btn.setBackgroundResource(R.drawable.vien_trai);
            btn.setTextColor(0xFF3E8E41);
        } else {
            btn.setText("Hôm nay con đã ăn chay");
            btn.setBackgroundResource(R.drawable.nut_chinh);
            btn.setTextColor(0xFFFFFDF7);
        }
    }

    private void capNhatThongKe() {
        Calendar hn = AmLich.homNay();
        int thang = p.soNgayChayTrongThang(hn);
        int nam = p.soNgayChayTrongNam(hn);
        int chuoi = p.chuoiLienTiep(hn);
        StringBuilder s = new StringBuilder();
        s.append("Tháng này: ").append(thang).append(" ngày chay\n");
        s.append("Năm ").append(hn.get(Calendar.YEAR)).append(": ").append(nam).append(" ngày chay");
        if (chuoi >= 2) {
            s.append("\nĐang giữ chuỗi ").append(chuoi).append(" ngày liên tiếp");
        }
        ((TextView) findViewById(R.id.tvThongKe)).setText(s.toString());
    }

    private void capNhatSapToi() {
        LinearLayout khung = (LinearLayout) findViewById(R.id.khungSapToi);
        khung.removeAllViews();
        Calendar hn = AmLich.homNay();
        List<NgayLe.SuKien> ds = NgayLe.sapToi(hn, 100, p.cheDoChay(), true);
        int dem = 0;
        LayoutInflater inf = LayoutInflater.from(this);
        for (NgayLe.SuKien s : ds) {
            if (s.conBaoNhieuNgay == 0) continue; // hom nay da hien o tren
            if (dem >= 12) break;
            khung.addView(taoDong(inf, khung, s));
            dem++;
        }
        if (dem == 0) {
            TextView tv = new TextView(this);
            tv.setText("Chưa có sự kiện nào sắp tới.");
            tv.setTextColor(0xFF9A8B78);
            khung.addView(tv);
        }
    }

    private View taoDong(LayoutInflater inf, ViewGroup cha, NgayLe.SuKien s) {
        View v = inf.inflate(R.layout.dong_su_kien, cha, false);
        ((TextView) v.findViewById(R.id.dsBadge1))
                .setText(String.valueOf(s.duong.get(Calendar.DAY_OF_MONTH)));
        ((TextView) v.findViewById(R.id.dsBadge2))
                .setText("th " + (s.duong.get(Calendar.MONTH) + 1));
        TextView ten = (TextView) v.findViewById(R.id.dsTen);
        ten.setText(s.tieuDe());
        if (s.le != null && s.le.laTrongDai()) ten.setTextColor(0xFF7B1E1E);

        String phu = AmLich.THU[s.duong.get(Calendar.DAY_OF_WEEK) - 1]
                + " • Âm lịch " + s.am.moTaNgan();
        if (s.ngayTrai && s.le != null) phu += " • Ngày trai";
        ((TextView) v.findViewById(R.id.dsPhu)).setText(phu);

        TextView con = (TextView) v.findViewById(R.id.dsConLai);
        if (s.conBaoNhieuNgay == 0) con.setText("Hôm nay");
        else if (s.conBaoNhieuNgay == 1) con.setText("Ngày mai");
        else con.setText("Còn " + s.conBaoNhieuNgay + "\nngày");

        if (s.le == null) {
            v.findViewById(R.id.dsKhungBadge).setBackgroundResource(R.drawable.vien_trai);
            ((TextView) v.findViewById(R.id.dsBadge1)).setTextColor(0xFF3E8E41);
        }
        return v;
    }

    // =====================================================================
    //  TRANG LICH
    // =====================================================================
    private void catDatTrangLich() {
        lich.setCheDoChay(p.cheDoChay());
        lich.setCallback(new LichThangView.OnChonNgay() {
            @Override
            public void chon(Calendar ngay) {
                hienChiTietNgay(ngay);
            }
        });
        findViewById(R.id.btnThangTruoc).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lich.doiThang(-1);
                capNhatTieuDeLich();
            }
        });
        findViewById(R.id.btnThangSau).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lich.doiThang(1);
                capNhatTieuDeLich();
            }
        });
        findViewById(R.id.btnVeHomNay).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar hn = AmLich.homNay();
                lich.veThang(hn.get(Calendar.YEAR), hn.get(Calendar.MONTH) + 1);
                lich.setNgayChon(hn);
                capNhatTieuDeLich();
                hienChiTietNgay(hn);
            }
        });
        capNhatTieuDeLich();
        hienChiTietNgay(AmLich.homNay());
    }

    private void capNhatTieuDeLich() {
        ((TextView) findViewById(R.id.tvThangNam))
                .setText("Tháng " + lich.getThang() + ", " + lich.getNam());
        ((TextView) findViewById(R.id.tvThangAm)).setText(lich.moTaAmLich());
    }

    private void hienChiTietNgay(Calendar c) {
        if (c == null) return;
        AmLich.Ngay am = AmLich.duongSangAm(c.get(Calendar.DAY_OF_MONTH),
                c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR));
        ((TextView) findViewById(R.id.tvChiTietNgay)).setText(
                AmLich.THU[c.get(Calendar.DAY_OF_WEEK) - 1] + ", "
                        + String.format("%02d/%02d/%d", c.get(Calendar.DAY_OF_MONTH),
                        c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR)));
        ((TextView) findViewById(R.id.tvChiTietAm)).setText(am.moTaDay()
                + " — ngày " + AmLich.canChiNgay(c.get(Calendar.DAY_OF_MONTH),
                c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR)));

        LinearLayout khung = (LinearLayout) findViewById(R.id.khungChiTiet);
        khung.removeAllViews();

        boolean trai = NgayLe.laNgayTrai(am, p.cheDoChay());
        if (trai) {
            TextView tv = new TextView(this);
            tv.setText("●  Ngày trai — xin phát tâm ăn chay");
            tv.setTextColor(0xFF3E8E41);
            tv.setTextSize(14);
            tv.setPadding(0, 0, 0, 8);
            khung.addView(tv);
        }
        List<NgayLe> les = NgayLe.vaoNgay(am);
        for (NgayLe l : les) {
            TextView t1 = new TextView(this);
            t1.setText(l.ten);
            t1.setTextColor(l.laTrongDai() ? 0xFF7B1E1E : 0xFF8A5A00);
            t1.setTextSize(15);
            t1.setTypeface(null, android.graphics.Typeface.BOLD);
            t1.setPadding(0, 6, 0, 0);
            khung.addView(t1);

            TextView t2 = new TextView(this);
            t2.setText(l.moTa);
            t2.setTextColor(0xFF3B2E20);
            t2.setTextSize(13.5f);
            t2.setLineSpacing(4f, 1f);
            t2.setPadding(0, 3, 0, 6);
            khung.addView(t2);
        }
        if (!trai && les.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("Ngày thường. Nam mô A Di Đà Phật.");
            tv.setTextColor(0xFF9A8B78);
            tv.setTextSize(14);
            khung.addView(tv);
        }
    }

    // =====================================================================
    //  TRANG DANH SACH
    // =====================================================================
    private void capNhatDanhSach() {
        LinearLayout khung = (LinearLayout) findViewById(R.id.khungDanhSach);
        if (khung == null) return;
        khung.removeAllViews();
        LayoutInflater inf = LayoutInflater.from(this);

        Calendar hn = AmLich.homNay();
        AmLich.Ngay amHN = AmLich.duongSangAm(hn.get(Calendar.DAY_OF_MONTH),
                hn.get(Calendar.MONTH) + 1, hn.get(Calendar.YEAR));
        ((TextView) findViewById(R.id.tvNamAm)).setText(
                "Năm " + amHN.canChiNam() + " — bấm vào từng ngày để xem ngày dương lịch tương ứng");

        int thangTruoc = -1;
        for (NgayLe l : NgayLe.tatCa()) {
            if (l.thangAm != thangTruoc) {
                thangTruoc = l.thangAm;
                View h = inf.inflate(R.layout.dong_tieu_de, khung, false);
                String ten;
                if (thangTruoc == 1) ten = "THÁNG GIÊNG";
                else if (thangTruoc == 11) ten = "THÁNG MỘT (11)";
                else if (thangTruoc == 12) ten = "THÁNG CHẠP";
                else ten = "THÁNG " + thangTruoc;
                ((TextView) h.findViewById(R.id.dtdTen)).setText(ten);
                khung.addView(h);
            }
            khung.addView(taoDongNgayLe(inf, khung, l, amHN.nam));
        }

        // Ngay trai trong thang am hien tai
        LinearLayout kt = (LinearLayout) findViewById(R.id.khungTrai);
        kt.removeAllViews();
        int[] ds = NgayLe.ngayTraiTrongThang(p.cheDoChay(), amHN.soNgayTrongThang);
        StringBuilder sb = new StringBuilder();
        sb.append(NgayLe.TEN_CHE_DO_CHAY[p.cheDoChay()]).append("\n");
        sb.append("Tháng ").append(amHN.tenThang()).append(" âm lịch có ")
                .append(amHN.soNgayTrongThang).append(" ngày.\n");
        if (p.cheDoChay() == NgayLe.CHAY_TRUONG) {
            sb.append("Trường chay — tất cả các ngày trong tháng.");
        } else {
            sb.append("Các ngày trai: ");
            for (int i = 0; i < ds.length; i++) {
                if (i > 0) sb.append(", ");
                sb.append(ds[i]);
            }
            sb.append(" (âm lịch)");
        }
        TextView tv = new TextView(this);
        tv.setText(sb.toString());
        tv.setTextColor(0xFF3B2E20);
        tv.setTextSize(14);
        tv.setLineSpacing(4f, 1f);
        tv.setBackgroundResource(R.drawable.vien_trai);
        int pad = (int) (12 * getResources().getDisplayMetrics().density);
        tv.setPadding(pad, pad, pad, pad);
        kt.addView(tv);
    }

    private View taoDongNgayLe(LayoutInflater inf, ViewGroup cha, final NgayLe l, int namAm) {
        View v = inf.inflate(R.layout.dong_su_kien, cha, false);
        ((TextView) v.findViewById(R.id.dsBadge1)).setText(String.valueOf(l.ngayAm));
        ((TextView) v.findViewById(R.id.dsBadge2)).setText("âm");
        TextView ten = (TextView) v.findViewById(R.id.dsTen);
        ten.setText(l.ten);
        if (l.laTrongDai()) ten.setTextColor(0xFF7B1E1E);

        int ngayThucTe = l.ngayAm;
        if (ngayThucTe == 30 && AmLich.soNgayThangAm(l.thangAm, namAm, false) == 29) {
            ngayThucTe = 29;
        }
        int[] duong = AmLich.amSangDuong(ngayThucTe, l.thangAm, namAm, false);
        String phu;
        if (duong != null) {
            phu = "Năm nay: " + String.format("%02d/%02d/%d", duong[0], duong[1], duong[2]);
        } else {
            phu = "Ngày " + l.ngayAm + " tháng " + l.thangAm + " âm lịch";
        }
        ((TextView) v.findViewById(R.id.dsPhu)).setText(phu);
        v.findViewById(R.id.dsConLai).setVisibility(View.GONE);

        final TextView mo = (TextView) v.findViewById(R.id.dsMoTa);
        mo.setText(l.moTa);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                mo.setVisibility(mo.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
        return v;
    }

    // =====================================================================
    //  TRANG CAI DAT
    // =====================================================================
    private boolean dangNap = false;

    private void catDatTrangCaiDat() {
        final EditText etTen = (EditText) findViewById(R.id.etTen);
        final EditText etPD = (EditText) findViewById(R.id.etPhapDanh);

        findViewById(R.id.btnLuuTen).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                p.setTen(etTen.getText().toString());
                p.setPhapDanh(etPD.getText().toString());
                anBanPhim(v);
                String t = p.tenHienThi();
                Toast.makeText(MainActivity.this,
                        t.length() > 0 ? ("Đã lưu. Kính chào Phật tử " + t)
                                : "Đã lưu thông tin", Toast.LENGTH_SHORT).show();
                capNhatTrangChu();
            }
        });

        findViewById(R.id.btnChaoLai).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ChaoMungActivity.class));
            }
        });

        RadioGroup rg = (RadioGroup) findViewById(R.id.rgCheDo);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int id) {
                if (dangNap) return;
                int cd = NgayLe.CHAY_THAP_TRAI;
                if (id == R.id.rb0) cd = NgayLe.CHAY_NHI_TRAI;
                else if (id == R.id.rb1) cd = NgayLe.CHAY_TU_TRAI;
                else if (id == R.id.rb2) cd = NgayLe.CHAY_LUC_TRAI;
                else if (id == R.id.rb3) cd = NgayLe.CHAY_THAP_TRAI;
                else if (id == R.id.rb4) cd = NgayLe.CHAY_TRUONG;
                p.setCheDoChay(cd);
                lich.setCheDoChay(cd);
                NhacNho.datLichNhac(MainActivity.this);
            }
        });

        Switch swTrai = (Switch) findViewById(R.id.swNhacTrai);
        swTrai.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean b) {
                if (dangNap) return;
                p.setNhacNgayTrai(b);
                NhacNho.datLichNhac(MainActivity.this);
            }
        });

        Switch swVia = (Switch) findViewById(R.id.swNhacVia);
        swVia.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean b) {
                if (dangNap) return;
                p.setNhacNgayVia(b);
                NhacNho.datLichNhac(MainActivity.this);
            }
        });

        Switch swChuong = (Switch) findViewById(R.id.swChuong);
        swChuong.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean b) {
                if (dangNap) return;
                p.setChuong(b);
            }
        });

        SeekBar sb = (SeekBar) findViewById(R.id.sbNhacTruoc);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int val, boolean fromUser) {
                capNhatNhanNhacTruoc(val);
                if (fromUser && !dangNap) {
                    p.setNhacTruoc(val);
                    NhacNho.datLichNhac(MainActivity.this);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });

        findViewById(R.id.btnGioNhac).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(MainActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int gio, int phut) {
                                p.setGioNhac(gio, phut);
                                ((Button) findViewById(R.id.btnGioNhac))
                                        .setText(String.format("%02d:%02d", gio, phut));
                                NhacNho.datLichNhac(MainActivity.this);
                                Toast.makeText(MainActivity.this,
                                        "Sẽ nhắc lúc " + String.format("%02d:%02d", gio, phut)
                                                + " mỗi ngày", Toast.LENGTH_SHORT).show();
                            }
                        }, p.gioNhac(), p.phutNhac(), true).show();
            }
        });

        findViewById(R.id.btnThuThongBao).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NhacNho.taoKenh(MainActivity.this);
                String t = p.tenHienThi();
                NhacNho.banTin(MainActivity.this, 9999,
                        "Thử thông báo — Lịch Vía Phật",
                        (t.length() > 0 ? ("Kính chào Phật tử " + t + ". ") : "")
                                + "Đây là thông báo thử. Nam mô A Di Đà Phật.",
                        p.chuong());
                Toast.makeText(MainActivity.this, "Đã gửi thông báo thử",
                        Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.tvCanhBaoPin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception ignored) {
                }
            }
        });

        ((TextView) findViewById(R.id.tvGioiThieu)).setText(
                "Lịch Vía Phật — Tịnh Thất A Di Đà\n\n"
                        + "Ứng dụng tổng hợp các ngày vía chư Phật, chư Bồ Tát, ngày đản sinh, "
                        + "thành đạo, nhập Niết Bàn, các đại lễ Phật giáo và các ngày trai "
                        + "(nhị trai, tứ trai, lục trai, thập trai) theo âm lịch Việt Nam.\n\n"
                        + "Ứng dụng chạy hoàn toàn ngoại tuyến, không thu thập dữ liệu, "
                        + "không quảng cáo. Mọi thông tin của quý Phật tử chỉ lưu trong máy.\n\n"
                        + "Nguyện đem công đức này, hướng về khắp tất cả, "
                        + "đệ tử và chúng sinh, đều trọn thành Phật đạo.\n\n"
                        + "Nam mô A Di Đà Phật.");

        napCaiDat();
    }

    private void capNhatNhanNhacTruoc(int val) {
        TextView tv = (TextView) findViewById(R.id.tvNhacTruoc);
        if (val == 0) tv.setText("Nhắc đúng ngày (không nhắc trước)");
        else if (val == 1) tv.setText("Nhắc trước 1 ngày (và đúng ngày)");
        else tv.setText("Nhắc trước " + val + " ngày (và đúng ngày)");
    }

    private void napCaiDat() {
        dangNap = true;
        ((EditText) findViewById(R.id.etTen)).setText(p.ten());
        ((EditText) findViewById(R.id.etPhapDanh)).setText(p.phapDanh());

        int cd = p.cheDoChay();
        int id = R.id.rb3;
        if (cd == NgayLe.CHAY_NHI_TRAI) id = R.id.rb0;
        else if (cd == NgayLe.CHAY_TU_TRAI) id = R.id.rb1;
        else if (cd == NgayLe.CHAY_LUC_TRAI) id = R.id.rb2;
        else if (cd == NgayLe.CHAY_TRUONG) id = R.id.rb4;
        ((RadioGroup) findViewById(R.id.rgCheDo)).check(id);

        ((Switch) findViewById(R.id.swNhacTrai)).setChecked(p.nhacNgayTrai());
        ((Switch) findViewById(R.id.swNhacVia)).setChecked(p.nhacNgayVia());
        ((Switch) findViewById(R.id.swChuong)).setChecked(p.chuong());
        ((SeekBar) findViewById(R.id.sbNhacTruoc)).setProgress(p.nhacTruoc());
        capNhatNhanNhacTruoc(p.nhacTruoc());
        ((Button) findViewById(R.id.btnGioNhac))
                .setText(String.format("%02d:%02d", p.gioNhac(), p.phutNhac()));
        dangNap = false;
    }

    private void anBanPhim(View v) {
        try {
            InputMethodManager imm =
                    (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }
}
