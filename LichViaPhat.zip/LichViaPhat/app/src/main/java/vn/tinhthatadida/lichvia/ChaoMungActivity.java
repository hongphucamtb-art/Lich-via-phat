package vn.tinhthatadida.lichvia;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

/** Man hinh chao mung lan dau mo app: ghi ten Phat tu va phap danh. */
public class ChaoMungActivity extends Activity {

    private Prefs p;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.chao_mung);
        p = new Prefs(this);

        Vien.apVien(findViewById(R.id.cmGoc), null, null);

        final EditText etTen = (EditText) findViewById(R.id.cmTen);
        final EditText etPD = (EditText) findViewById(R.id.cmPhapDanh);
        final RadioGroup rg = (RadioGroup) findViewById(R.id.cmRg);

        etTen.setText(p.ten());
        etPD.setText(p.phapDanh());
        rg.check(idTheoCheDo(p.cheDoChay()));

        findViewById(R.id.cmBatDau).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                p.setTen(etTen.getText().toString());
                p.setPhapDanh(etPD.getText().toString());
                p.setCheDoChay(cheDoTheoId(rg.getCheckedRadioButtonId()));
                p.setDaChao(true);
                NhacNho.taoKenh(ChaoMungActivity.this);
                NhacNho.datLichNhac(ChaoMungActivity.this);
                String t = p.tenHienThi();
                Toast.makeText(ChaoMungActivity.this,
                        t.length() > 0
                                ? ("Kính chào Phật tử " + t + ". Nam mô A Di Đà Phật")
                                : "Nam mô A Di Đà Phật",
                        Toast.LENGTH_LONG).show();
                finish();
            }
        });

        findViewById(R.id.cmBoQua).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                p.setDaChao(true);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        p.setDaChao(true);
        finish();
    }

    static int idTheoCheDo(int cd) {
        if (cd == NgayLe.CHAY_NHI_TRAI) return R.id.cmRb0;
        if (cd == NgayLe.CHAY_TU_TRAI) return R.id.cmRb1;
        if (cd == NgayLe.CHAY_LUC_TRAI) return R.id.cmRb2;
        if (cd == NgayLe.CHAY_TRUONG) return R.id.cmRb4;
        return R.id.cmRb3;
    }

    static int cheDoTheoId(int id) {
        if (id == R.id.cmRb0) return NgayLe.CHAY_NHI_TRAI;
        if (id == R.id.cmRb1) return NgayLe.CHAY_TU_TRAI;
        if (id == R.id.cmRb2) return NgayLe.CHAY_LUC_TRAI;
        if (id == R.id.cmRb4) return NgayLe.CHAY_TRUONG;
        return NgayLe.CHAY_THAP_TRAI;
    }
}
