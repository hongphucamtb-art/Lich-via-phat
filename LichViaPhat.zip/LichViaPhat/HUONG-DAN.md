# Lịch Vía Phật — Tịnh Thất A Di Đà - Châu Đốc

Ứng dụng Android tổng hợp **ngày vía chư Phật, chư Bồ Tát**, ngày **đản sinh – thành đạo –
nhập Niết Bàn**, các **đại lễ Phật giáo** và các **ngày trai** (nhị trai, tứ trai, lục trai,
thập trai) theo âm lịch Việt Nam, kèm **nhắc nhở ăn chay** đúng giờ.

---

## 1. Ứng dụng có gì

| Màn hình | Nội dung |
|---|---|
| **Chào mừng** | Hiện ngay lần đầu mở ứng dụng: mời Phật tử ghi **họ tên**, **pháp danh** và chọn **chế độ ăn chay**. Từ đó mỗi ngày mở app đều được kính chào đích danh. Mở lại bất cứ lúc nào trong Cài đặt |
| **Hôm nay** | Ngày dương – ngày âm – can chi, báo ngày trai, ngày lễ hôm nay, nút "Hôm nay con đã ăn chay", thống kê số ngày chay trong tháng/năm và chuỗi ngày liên tiếp, lời Phật dạy mỗi ngày, danh sách sự kiện sắp tới |
| **Lịch** | Lịch tháng dương kèm ngày âm; chấm xanh = ngày trai, viền vàng = ngày vía, viền vàng đậm = đại lễ. Bấm vào ngày để xem ý nghĩa |
| **Ngày lễ** | Toàn bộ 36 ngày vía – đại lễ theo tháng âm, kèm ngày dương lịch tương ứng của năm nay và ý nghĩa từng ngày |
| **Cài đặt** | Ghi **họ tên và pháp danh** Phật tử, chọn **chế độ ăn chay**, bật/tắt nhắc, **nhắc trước 0–7 ngày**, **chọn giờ nhắc**, bật/tắt âm thanh, nút thử thông báo |

Đặc điểm kỹ thuật:

- Chạy được từ **Android 5.0 (API 21)** đến **Android 16 (API 36)** — máy cấu hình thấp vẫn mượt.
- **Không dùng thư viện ngoài**, file APK chỉ khoảng **300 KB**.
- Đã xử lý **tràn viền màn hình** (edge-to-edge) theo chuẩn Android 15/16.
- **Chạy hoàn toàn ngoại tuyến**, không cần mạng, không quảng cáo, không thu thập dữ liệu.
- Nhắc nhở bằng `AlarmManager`, **tự đặt lại sau khi khởi động lại máy**.
- Tự xử lý **tháng thiếu (29 ngày)**: ngày 28–29–30 của thập trai lùi thành 27–28–29 theo cổ lệ.

---

## 2. Cách lấy file APK — Cách 1: dùng GitHub (không cần cài phần mềm)

Cách này chạy trên máy chủ miễn phí của GitHub, mất khoảng **10 phút**, làm một lần duy nhất.

1. Vào <https://github.com> → đăng ký / đăng nhập tài khoản miễn phí.
2. Bấm dấu **+** góc trên bên phải → **New repository**.
   - Repository name: `lich-via-phat`
   - Chọn **Private** (riêng tư) cũng được.
   - **Không** tích "Add a README file".
   - Bấm **Create repository**.
3. Ở trang vừa hiện ra, bấm dòng **uploading an existing file**.
4. **Giải nén** file `LichViaPhat-Android-source.zip` trên máy tính, rồi **kéo toàn bộ nội dung
   bên trong** (thư mục `app`, `gradle`, `.github`, các file `gradlew`, `build.gradle`,
   `settings.gradle`, `gradle.properties`, `tinhthat.jks`…) thả vào trang GitHub.
   > Lưu ý: kéo **nội dung bên trong** thư mục, không kéo cả thư mục mẹ.
5. Bấm **Commit changes**.
6. Chuyển sang thẻ **Actions** ở đầu trang. Sẽ thấy tiến trình **"Tạo file APK và AAB"** đang chạy
   (vòng tròn màu vàng). Đợi khoảng **3–5 phút** cho tới khi thành dấu **✓ xanh**.
7. Bấm vào tiến trình đó → kéo xuống mục **Artifacts** → tải **`LichViaPhat`** về máy.
   Giải nén ra sẽ có **hai file**:
   - **`LichViaPhat-CaiTrucTiep.apk`** — cài thẳng vào điện thoại.
   - **`LichViaPhat-CHPlay.aab`** — file để nộp lên Google Play Console.
   > Hai file này cũng tự xuất hiện ở thẻ **Releases** bên phải trang chính, tải trực tiếp
   > bằng điện thoại được luôn.

Sau này mỗi lần sửa gì trong mã nguồn và bấm Commit, GitHub sẽ **tự build lại bản mới**.

---

## 3. Cách lấy file APK — Cách 2: dùng Android Studio

1. Tải Android Studio: <https://developer.android.com/studio> (miễn phí).
2. Giải nén `LichViaPhat-Android-source.zip`.
3. Mở Android Studio → **Open** → chọn thư mục vừa giải nén → đợi tải xong thư viện.
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Menu **Build → Generate Signed Bundle / APK** nếu muốn file AAB cho CH Play.
6. File kết quả nằm ở:
   - APK: `app/build/outputs/apk/tructiep/release/`
   - AAB: `app/build/outputs/bundle/chplayRelease/`

   > Trong Android Studio, chọn biến thể build ở góc dưới bên trái
   > (**Build Variants**): `tructiepRelease` hoặc `chplayRelease`.

Hoặc dùng dòng lệnh trong thư mục dự án:

```bash
./gradlew assembleTructiepRelease   # ra file APK cài trực tiếp
./gradlew bundleChplayRelease       # ra file AAB nộp lên CH Play
```

### Hai phiên bản khác nhau chỗ nào

| | `tructiep` (file APK) | `chplay` (file AAB) |
|---|---|---|
| Dùng để | Cài thẳng vào máy, phát cho Phật tử | Nộp lên Google Play |
| Quyền báo thức chính xác | **Có** — nhắc đúng từng phút | **Không** — Google chỉ cấp quyền này cho app đồng hồ báo thức và lịch chuyên dụng |
| Độ chính xác khi nhắc | Đúng phút đã đặt | Đúng ngày, có thể lệch vài phút khi máy ngủ sâu |

Mọi tính năng khác hoàn toàn giống nhau.

---

## 4. Cài APK lên điện thoại Android

1. Chép file `.apk` vào điện thoại (qua Zalo, email, USB, hoặc tải thẳng từ Releases).
2. Mở file → Android sẽ hỏi cho phép cài từ nguồn này → chọn **Cài đặt / Vẫn cài**.
3. Mở app → cho phép **gửi thông báo** khi được hỏi.
4. Vào **Cài đặt** trong app → ghi **tên / pháp danh**, chọn **chế độ ăn chay**,
   chọn **nhắc trước mấy ngày** và **giờ nhắc** → bấm **Thử một thông báo** để kiểm tra.

### Nếu không nhận được thông báo

Nhiều điện thoại (Xiaomi, Oppo, Vivo, Samsung, Huawei…) tự tắt ứng dụng chạy nền. Xin làm thêm:

- **Cài đặt điện thoại → Ứng dụng → Lịch Vía Phật → Pin →** chọn **Không giới hạn / Không tối ưu hoá**.
- **Cài đặt → Ứng dụng → Lịch Vía Phật → Thông báo →** bật tất cả.
- Với máy Xiaomi/Redmi: vào **Ứng dụng gần đây**, giữ thẻ ứng dụng → bấm **khoá** (biểu tượng ổ khoá).

---

## 5. Muốn sửa nội dung

| Muốn sửa | Mở file |
|---|---|
| Thêm / bớt ngày vía, sửa ý nghĩa | `app/src/main/java/vn/tinhthatadida/lichvia/NgayLe.java` |
| Thêm lời Phật dạy | `app/src/main/java/vn/tinhthatadida/lichvia/PhatNgon.java` |
| Đổi tên tịnh thất hiển thị trên đầu app và màn hình chào mừng | `app/src/main/res/values/strings.xml` (dòng `tinh_that`) |
| Đổi tên ứng dụng | `app/src/main/res/values/strings.xml` (dòng `app_name`) |
| Đổi màu sắc | `app/src/main/res/values/colors.xml` |
| Sửa màn hình chào mừng | `app/src/main/res/layout/chao_mung.xml` |
| Đổi biểu tượng app | `app/src/main/res/mipmap-*/ic_launcher.png` và `drawable/ic_launcher_foreground.xml` |
| Tăng số phiên bản khi phát hành bản mới | `app/build.gradle` (`versionCode`, `versionName`) |

Sau khi sửa, build lại APK theo mục 2 hoặc 3.

> **Về file `tinhthat.jks`**: đây là khoá ký ứng dụng. Xin **giữ nguyên file này** cho mọi bản
> cập nhật sau — nếu đổi khoá, điện thoại sẽ không cho cài đè lên bản cũ. Mật khẩu khoá là
> `tinhthatadida` (ghi trong `app/build.gradle`).

---

## 6. Đưa ứng dụng lên CH Play

Toàn bộ hồ sơ đã được chuẩn bị sẵn trong thư mục **`ho-so-chplay/`**:

- `icon-512.png` và `anh-bia-1024x500.png` — đúng kích thước Google yêu cầu
- `anh-man-hinh/` — 5 ảnh 1080×1920
- `MO-TA-CH-PLAY.md` — tên app, mô tả ngắn, mô tả đầy đủ, cách trả lời các biểu mẫu
- `chinh-sach-bao-mat.html` — chính sách bảo mật, chỉ cần đăng lên mạng lấy link
- `HUONG-DAN-DANG-CH-PLAY.md` — hướng dẫn từng bước, kể cả bước thử nghiệm 12 Phật tử

Xin đọc `ho-so-chplay/HUONG-DAN-DANG-CH-PLAY.md` trước khi bắt đầu.

---

## 7. Bản web dùng ngay

File `LichViaPhat-TinhThatADiDa.html` là bản web cùng giao diện và cùng dữ liệu, mở được
bằng trình duyệt trên bất kỳ điện thoại nào mà không cần cài đặt:

1. Chép file vào điện thoại, mở bằng **Chrome**.
2. Bấm menu ⋮ → **Thêm vào màn hình chính** để dùng như một ứng dụng.

Bản web nhắc nhở được **khi trình duyệt còn mở**. Muốn nhắc đúng giờ kể cả khi tắt máy hoặc
tắt ứng dụng thì xin dùng bản APK.

---

*Nguyện đem công đức này, hướng về khắp tất cả, đệ tử và chúng sinh, đều trọn thành Phật đạo.*

**Nam mô A Di Đà Phật.**
